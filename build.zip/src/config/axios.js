import axios from "axios";

export const url = process.env.REACT_APP_BACK_URL

const instance = axios.create({
  baseURL: url
});

instance.interceptors.request.use(function (config) {

  if (!window.store || !window.store.getState().userReducer || !window.store.getState().userReducer.user) return config;

  const { token } = window.store.getState().userReducer.user;

  if (!token) return config;

  config.headers.Authorization = `Bearer ${token}`

  return config;
}, function (error) {
  if (error && error.hasOwnProperty('status') && error.status === 401) {
    return window.location.href = `${process.env.REACT_APP_FRONT_URL}/login`
  }
  return Promise.reject(error)
})


instance.interceptors.response.use(
  function (response) {
    return response.data;
  },
  function (error) {
    const errors = [401]
    if (error && error.response && error.response.hasOwnProperty('status') && errors.includes(error.response.status)) {
      window.store.dispatch({ type: 'SET_USER_INITIAL' })
      return window.location.href = `${process.env.REACT_APP_FRONT_URL}/login`
    }
    return Promise.reject(error);
  }
);

export default instance;
