import React, { Component } from "react";
import "./style.scss";
import Grid from "components/Grid"
import { PageContainer } from "components/Partials"

import GridPopUp from "components/Grid/components/gridPopUp"
import * as homeActions from 'redux/reducers/homeReducer'
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import IconProvider from "components/IconProvider";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPlusCircle, faFile, faSearch, faEllipsisV, faCopy } from '@fortawesome/free-solid-svg-icons'
import { Link } from "react-router-dom";
import { contracts } from "redux/reducers/homeReducer";
import Sortable from "components/Grid/components/sortable"
import Compare_Icon from "assets/images/Compare_Icon.png";
import Paginator from "components/Paginator"
import _ from "lodash";

const defaultColumnProperties = {
    sortable: true,
};

const lastColumnsActions = [
    {
        icon: <IconProvider icon={faEllipsisV} style={{
            color: "#9b9b9b", width: "25px",
            height: "25px"
        }} />,
        actions: [
            {
                text: <GridPopUp
                    lines={["View", "Edit", "Inactive", "Delete"]}
                    onClick={(line) => {
                        //TODO LINK ACTIONS
                    }}
                />,
            },
        ]
    },
]

class Home extends Component {

    state = {
        search: ""
    }

    componentDidMount() {
        const { list } = this.props.homeActions;
        list();
    }

    getColumns = () => {

        const keys = [
            "Status",
            "Contract ID",
            "Contract Name",
            "Contract Group",
            "Client Type",
            "Contract Template",
            "Contract Type",
        ]

        const columns = keys.map((item, key) => {
            return {
                key: item,
                name: [defaultColumnProperties.hasOwnProperty("sortable") ? <Sortable child={item} /> : { item }],
                ...defaultColumnProperties
            }
        })

        return columns
    }

    sortRows = (initialRows, sortColumn, sortDirection) => {
        return this.props.homeActions.sort(sortColumn, sortDirection)
    };

    getCellActions(column, row) {

        const color = row.Status == "Active" ? "#42B953" : "#cecece";

        const cellActions = {
            "Contract Type": lastColumnsActions,
            "Status": [
                {
                    icon: <div className="status-icon" style={{ backgroundColor: color }}></div>,
                    callback: () => {
                        alert("Deleting");
                    }
                }
            ]
        };

        return cellActions[column.key];
    }

    render() {
        const { contracts } = this.props
        return (
            <>
                <PageContainer title="CONTRACTS">
                    <div className="flex-1 table-title f-2 align-items-baseline">
                        List of Contracts
                    </div>
                    <div className="flex-2 table-title f-1 d-flex justify-content-end align-items-baseline">
                        <div className="btn-container mlr d-flex align-items-center btn-link-div">
                            <IconProvider icon={faPlusCircle} style={{
                                width: "14px",
                                height: "14px"
                            }} />
                            <Link to="/new-contract" className="default-link-router">CREATE NEW</Link>
                        </div>
                        <div className="btn-container d-flex mlr align-items-center btn-link-div">
                            <IconProvider icon={faCopy} style={{
                                width: "14px",
                                height: "14px",
                            }} />
                            <Link className="default-link-router">COMPARE</Link>
                        </div>
                        <div className="input-search-container d-flex align-items-center">
                            <IconProvider icon={faSearch} style={{
                                color: "#CFCFCF", fontSize: "15px"
                            }} />
                            <input
                                type="text"
                                value={this.state.search}
                                className="input-search"
                                placeholder="Search..." onChange={(e) => {
                                    this.setState({
                                        search: e.target.value
                                    })
                                }}
                            />
                            <div className="btn-search cp" onClick={() => this.props.homeActions.search(this.state.search)}>
                                OK
                            </div>
                        </div>
                    </div>
                    <div style={{ height: "100%", width: "100%", marginTop: '8px' }}>
                        <Grid
                            getCellActions={this.getCellActions}
                            columns={this.getColumns()}
                            rows={contracts}
                            onSort={(sortColumn, sortDirection) => this.sortRows(this.props.contracts, sortColumn, sortDirection)}
                        />
                        <div className="paginator-container">
                            <Paginator
                                totalPages={this.props.totalPages}
                                currentPage={this.props.currentPage}
                                canChangeQtyPage={this.props.canChangeQtyPage}
                                changePage={(newPage) => this.props.homeActions.changePage(newPage)}
                            />
                        </div>
                    </div>
                </PageContainer>
            </>
        )
    }
}

const mapStateToProps = state => ({
    contracts: contracts(state).contracts,
    totalPages: contracts(state).totalPages,
    currentPage: state.homeReducer.currentPage,
    canChangeQtyPage: state.homeReducer.canChangeQtyPage,
    search: state.homeReducer.search,
})

const mapDispatchToProps = dispatch => {
    return {
        homeActions: bindActionCreators(homeActions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Home)