import React, { Component } from "react";
import "./style.scss";
import logo from "assets/images/spectra_logo.png";
import { faLock, faAt } from '@fortawesome/free-solid-svg-icons'
import { Link } from "react-router-dom";
import CustomInput from "components/CustomInput";
import { errorsEnum } from "enums";
import _ from "lodash";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import * as actions from "redux/reducers/userReducer";
import {withRouter} from "react-router-dom"

class SignIn extends Component {
    state = {
        email: "",
        password: "",
        errors: {},
        keepLogged: false
    }

    componentWillMount(){
        this.props.actions.logout()
    }

    handleChange = target => {
        this.setState({
            [target.name]: target.value
        });
    };

    componentDidUpdate(prevProps, prevState) {
        if (_.isEqual(prevState, this.state)) return false;
        const keysState = Object.keys(this.state);
        keysState.forEach((item, key) => {
            if (!_.isEqual(prevState[item], this.state[item]) && this.state.errors.hasOwnProperty(item)) {
                this.setState({
                    errors: delete this.state.errors[item]
                })
            }
        })
    }

    signIn = () => {
        let errors = { ...this.state.errors };

        if (!this.state.email.length) {
            errors.email = errorsEnum.valid_email;
        }
        if (!this.state.password.length) {
            errors.password = errorsEnum.valid_password;
        }

        if(Object.keys(errors).length){
            return this.setState({ errors })
        }

        this.props.actions.login(this.state)
    };

    componentWillReceiveProps(nextProps){
        if(!!nextProps.user){
            this.props.history.push("/")
        }
    }

    forgotPassword = () => {
        console.log("forgot password");
        return
    }

    render() {
        const { keep_login } = this.state;
        return (
            <div className="bg-blue">
                <div className="container">
                    <div className="row justify-content-md-center">
                        <div className="col-10">
                            <div className="bgWhite">
                                <div className="leftDiv">
                                    <div class="overlay"></div>
                                    <p className="welcome-text">
                                        <span>Welcome to <br /></span>
                                        <span>The SpectraMedix Platform <br /> For Health Plans</span>
                                    </p>
                                </div>
                                <div className="rightDiv">
                                    <div className="row">
                                        <div className="col-12 d-flex justify-content-center">
                                            <img className="logo" src={logo} />
                                        </div>
                                        <div className="col-12 box-input">
                                            <CustomInput name={"email"} type={"email"} leftIcon={faAt} placeHolder={"Email..."} handleChange={this.handleChange} required={true} error={this.state.errors.email} />
                                        </div>
                                        <div className="col-12 box-input m-0">
                                            <CustomInput name={"password"} type={"password"} leftIcon={faLock} placeHolder={"Password..."} handleChange={this.handleChange} required={true} error={this.state.errors.password} />
                                        </div>
                                        <div className="col-12 pt0 box-input m-0 mt-3 flex-end align-items-center">
                                            <div onClick={() => this.setState({ keep_login: !keep_login })} className="d-flex align-items-center">
                                                <input checked={keep_login} type="checkbox" />
                                                <label className="marginl-5 grey-color">Keep me logged in</label>
                                            </div>
                                            <Link to="forgot-password">
                                                <a className="default-link-router font-italic" onClick={() => this.forgotPassword()}>Forgot password?</a>
                                            </Link>
                                        </div>
                                        <div className="col-12 d-flex justify-content-center mt-20">
                                            <button type="button" className="btn-primary btn-block rounded-pill w-300 button-shaddow" onClick={() => this.signIn()}>SIGN IN</button>
                                        </div>
                                        <div className="col-12 font-italic d-flex justify-content-center w-100 mt-10 mt-20">
                                            <a className="default-link-router" onClick={() => this.forgotPassword()}>Confidentiality Disclaimer</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = state => ({
    user: state.userReducer.user
});

const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators(actions, dispatch)
})

SignIn = connect(mapStateToProps, mapDispatchToProps)(SignIn)

export default withRouter(SignIn);
