import React, { Component } from "react";
import "./style.scss";
import logo from "assets/images/spectra_logo.png";
import at from "assets/images/at.png";
import CustomInput from "components/CustomInput";

export default class ForgotPassword extends Component {
    state = {
        email: "",
    }


    handleChange = target => {
        this.setState({
            [target.name]: target.value
        });
    };

    forgotPassword = () => {
        return ;
    }

    render() {
        return (
            <div className="container-fluid p-0 m-0 vh-100 page-login d-flex justify-content-center align-items-center page-forgot-password">
                <div className="row p-0 m-0 d-flex h-100 w-100 justify-content-center align-items-center">
                    <div className="col-md-4 p-0 m-0 bg-white h-75 d-flex justify-content-center box-login">
                        <div className="col-xl-12">
                            <div className="row">
                                <div className="col-12 d-flex justify-content-center">
                                    <img className="" src={logo} />
                                </div>
                                <div className="col-12 box-input">
                                    <CustomInput name={"email"} type={"email"} leftImage={at} placeHolder={"Email..."} handleChange={this.handleChange} required={true}/>
                                </div>
                                <div className="col-12 d-flex justify-content-center button-height">
                                    <button type="button" className="btn-primary btn-block rounded-pill w-50 button-shaddow" onClick={() => this.forgotPassword()}>SEND EMAIL</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}


