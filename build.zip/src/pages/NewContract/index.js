import React from "react";
import { PageContainer } from "components/Partials"
import { Switch, Route, BrowserRouter } from "react-router-dom";
 
import "./style.scss";
import * as actionsContract from "redux/reducers/contractReducer";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { getCurrentStep, getContractTitle } from "redux/reducers/contractReducer"
import Step0 from "./Steps/0"
import MarketParameters from "./Steps/1/MarketParameters"
import FinancialBenchmark from "./Steps/1/FinancialBenchmark"
import LeftSideBar from "./components/LeftSideBar"
import Middle from "./components/Middle"
import HeaderPage from "./components/HeaderPage"
import PageContractContainer from "./components/ContractContainer"
import ProviderNetwork from "./Steps/1/ProviderNetwork";
import ContractParameters from "./Steps/2/"
import _ from "lodash";

const Profile = () => <div>You're on the Profile Tab</div>;

class NewContract extends React.Component {

    

    expand = (obj) => {
        let menu = { ...this.props.menu };

        let step = this.props.getCurrentStep.step;

        if (obj.opt == "all") {
            for (let i in menu) {
                menu[i].check = !menu[i].check;
            }
        } else if (obj.item == null) {
            menu[obj.opt].check = !menu[obj.opt].check;
        } else {
            Object.keys(menu).map((opt) => {
                menu[opt].options.map((itm) => itm.check = false)
            });
            menu[obj.opt].options[obj.item].check = !menu[obj.opt].options[obj.item].check;
        }

        if (obj.opt != "all" && obj.opt != step) {
            this.props.actionsContract.changeStep({ step: obj.opt })
        }
        this.props.actionsContract.toogle_expand_filter(menu);
    }

    onFieldChange = (field_name, field_value) => {
        let newContract = { ...this.props.contract }
        newContract[field_name] = field_value;
        this.props.actionsContract.changeContract({ ...newContract })
    }

    btnContinue = () => {
        let menuObj = { ...this.props.menu };
        
        let nextStep = this.props.getCurrentStep.nested_step + 1;
        const nested_step = this.props.getCurrentStep.nested_step;
        let step = this.props.getCurrentStep.step;
        let sts = menuObj[step].options;

   
        // console.log(menuObj[step].options)
        if (_.findIndex((menuObj[step].options), (opt, k) => nextStep == k) >= 0) {
            menuObj[step].options[nested_step].check = false;
            menuObj[step].options[nested_step].finished = true;
            menuObj[step].options[nextStep].check = true;
        } else {
            menuObj[step].options[nested_step].check = false;
            menuObj[step].options[nested_step].finished = true;
            step = parseInt(step) + 1
            menuObj[step].options[0].check = true;
        }
        this.props.actionsContract.changeStep({ step })
        this.props.actionsContract.toogle_expand_filter(menuObj)
    }

    render() {
        let p = this.props;
        console.log()

        
  
        return (
       
            <div className="create-new-contract">
                {this.props.getCurrentStep.step == 0 &&
                    <PageContainer title="CREATE NEW CONTRACT">
                        <Step0 />
                    </PageContainer>
                }
                {this.props.getCurrentStep.step > 0 &&
                    <PageContractContainer title={this.props.title}>
                        <HeaderPage />
                        <div className="contract-area col-md-12 m-0 p-0">
                            <div className="row m-0" style={{display: 'flex'}}>
                                <div className="contract-container p-0" style={{width: '300px'}}>
                                    <LeftSideBar menu={this.props.menu} expand={(obj) => this.expand(obj)} />
                                </div>
                                <div className="px-0 right-side-container" style={{flex: 1}}>
                                    <Middle>

                                        {this.props.getCurrentStep.step == 1 &&
                                            <>
                                      
                                                {this.props.getCurrentStep.nested_step == 0 &&
                                                    <MarketParameters
                                                        btnContinue={() => this.btnContinue()}
                                                        {...this.props}
                                                        step={this.props.getCurrentStep.step}
                                                        nested_step={this.props.getCurrentStep.nested_step}
                                                        onChange={this.onFieldChange}
                                                        continueSteps={(menu) => this.props.actionsContract.toogle_expand_filter(menu)}
                                                    />
                                                    
                                                }
                                                
                                                {this.props.getCurrentStep.nested_step == 1 &&
                                                    <FinancialBenchmark
                                                        btnContinue={() => this.btnContinue()}
                                                        {...this.props}
                                                        step={this.props.getCurrentStep.step}
                                                        nested_step={this.props.getCurrentStep.nested_step}
                                                        onChange={this.onFieldChange}
                                                        continueSteps={(menu) => this.props.actionsContract.toogle_expand_filter(menu)}
                                                    />
                                                }
                                                {this.props.getCurrentStep.nested_step == 2 &&
                                                    <ProviderNetwork
                                                        btnContinue={() => this.btnContinue()}
                                                        {...this.props}
                                                        step={this.props.getCurrentStep.step}
                                                        nested_step={this.props.getCurrentStep.nested_step}
                                                        onChange={this.onFieldChange}
                                                        continueSteps={(menu) => this.props.actionsContract.toogle_expand_filter(menu)}
                                                    />
                                                }
                                              
                                            </>
                                        }
                                        {this.props.getCurrentStep.step == 2 &&
                                            <ContractParameters
                                                btnContinue={() => this.btnContinue()}
                                            />
                                        }
                                    </Middle>
                                </div>
                            </div>
                        </div>
                    </PageContractContainer>
                }
            </div >
        )
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        actionsContract: bindActionCreators(actionsContract, dispatch)
    }
}

const mapStateToProps = (state) => {
    return {
        menu: state.contractReducer.left_menu_new_contract,
        getCurrentStep: getCurrentStep(state),
        title: getContractTitle(state),
        contract: state.contractReducer.contract
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(NewContract)