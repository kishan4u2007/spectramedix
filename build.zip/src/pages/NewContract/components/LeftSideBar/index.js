import React from "react";
import {  BrowserRouter as Router } from 'react-router-dom'
import "./style.scss"
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faChevronDown, faChevronRight } from '@fortawesome/free-solid-svg-icons'
import { Link } from 'react-router-dom'

export default ({ menu, expand, props, match }) => {

    const items = Object.keys(menu);

    console.log(props)

    function handleSelect(route) {
        
        this.props.history.push(route)
      }

      
    return (
        <div className="row left-side-bar-container m-0 p-0" style={{display: 'flex', flexDirection: 'column'}}>
            <div className="text-right" onClick={() => expand({ opt: "all", item: null })} style={{color: '#598ed2'}}>
                EXPAND ALL
            </div>
            {items.map((opt, keyOpt) => {
                return (
                    <div className={`step-container ${keyOpt > 0 ? "" : ""}`} style={{minHeight: '45px'}}>
                        <div className="ball-container d-flex">
                            <div className="" style={{zIndex: 1}}>
                                <div className={`ball-number ${menu[opt].check || menu[opt].finished}`}>
                                    {opt}
                                </div>
                            </div>
                            <div className="left-items flex-1 d-flex">
                                <div className="ball-title">
                                    {menu[opt].title}
                                </div>
                            </div>
                            <div className="expand justify-content-flex-end">
                                {!!menu[opt].expanded ? <FontAwesomeIcon icon={faChevronDown} style={{
                                    width: "18px",
                                    height: "18px",
                                    color: "#a9a9a9"
                                }}
                                />
                                    :
                                    <FontAwesomeIcon icon={faChevronRight} style={{
                                        width: "18px",
                                        height: "18px",
                                        color: "#a9a9a9"
                                    }}
                                    />
                                }
                            </div>
                        </div>
                        {!menu[opt].check &&
                            <div className="line-bottom-ball-closed" />
                        }
                        {!!menu[opt].check && menu[opt].options.map((option, key) =>
                            <div className="options-container d-flex">
                                <div className={`left-indicator ${key > 0 ? "child" : ""} ${(option.check || option.finished)}`} />
                                <div className={`ball-option-container d-flex`}>
                                    <div className="ball-item-container">
                                        <div className={"ball-option " + (option.check || option.finished)} />
                                        {key + 1 < menu[opt].options.length &&
                                            <div className={"bottom-indicator " + (option.check || option.finished)} />
                                        }
                                    </div>
                                </div>
                                <div className={"title-option " + (option.check || option.finished)}>
                             
                                    <Link to={"/new-contract/" + option.title.replace(/ +/g, "")}>  {option.title}</Link>
                                  
                                </div>
                            </div>
                        )}
                         
                    </div>
                )
            })}
           
        </div>
        
    )
}
