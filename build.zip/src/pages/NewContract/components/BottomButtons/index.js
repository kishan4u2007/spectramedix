import React from "react";
import { Link } from "react-router-dom";
import CustomButton from "components/CustomButton"

export default ({step, nested_step, disabled, btnBack, btnContinue, showBack=true}) => {
    // const disabled = disabled ? disabled : step == 1 && nested_step == 0;
    return (
        <div class="col-sm-12 d-flex justify-content-center">
            <Link to="/" style={{ textDecoration: 'initial' }}>
                <CustomButton title={"Cancel"} disabled={true} className="mDefault" />
            </Link>
            {
                !!showBack && <CustomButton className="mDefault" disabled={step == 1 && nested_step == 0} title={"Back"} onClick={() => !disabled ? btnBack() : ""} />
            }
            <CustomButton className="mDefault" title={"Continue"} onClick={() => btnContinue()} />
        </div>
    )
}