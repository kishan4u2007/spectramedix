import React from "react"
import "./style.scss"

export default (props) => {
    return (
        <div className="middle-container contract-container p-0 ml-3">
            <div className="col-md-12 m-0 p-0 h-100">
                {props.children}
            </div>
        </div>
    )
}