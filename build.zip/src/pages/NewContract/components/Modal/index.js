import React from "react";
import "./style.scss";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faTimes } from '@fortawesome/free-solid-svg-icons'
import onClickOutside from "react-onclickoutside";

class Modal extends React.Component {

    handleClickOutside = evt => {
        if (this.props.onClose) {
            this.props.onClose();
        }
    };

    render() {

        if (!this.props.open) return false;
        return (
            <div className="modal_contract">
                <div className="modal_container">
                    <div className="modal_container_header">
                        <div className="flex-1">
                        </div>
                        <div className="flex-1 text-center">
                            {this.props.title}
                        </div>
                        <div className="flex-1 text-right">
                            <FontAwesomeIcon icon={faTimes} style={{
                                width: "22px",
                                height: "22px",
                                marginRight: "20px",
                                cursor: "pointer",
                            }}
                                onClick={() => this.props.onClose()}
                            />
                        </div>
                    </div>
                    <div className="modal_middle">
                        {this.props.children}
                    </div>
                </div>
            </div>
        )
    }
}

export default onClickOutside(Modal);