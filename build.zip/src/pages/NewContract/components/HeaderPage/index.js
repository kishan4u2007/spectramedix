import React from "react";
import "./style.scss";

export default (props) => (
    <div className="col-md-12 header-contract-page p-0 mt-0">
        <div className="item-container d-flex justify-content-space p-0 my-2">
            <div className="col-md-3 d-flex justify-content-center py-2">
                <div className="title">
                    Contract Name
                    <div className="sub-title">
                        XXXXXX
                    </div>
                </div>
            </div>
            <div className="col-md-3 d-flex justify-content-center p-2">
                <div className="title">
                    Contract Name
                    <div className="sub-title">
                        XXXXXX
                    </div>
                </div>
            </div>
            <div className="col-md-3 d-flex justify-content-center p-2">
                <div className="title">
                    Contract Name
                    <div className="sub-title">
                        XXXXXX
                    </div>
                </div>
            </div>
            <div className="col-md-3 d-flex justify-content-center p-2">
                <div className="title">
                    Contract Name
                    <div className="sub-title">
                        XXXXXX
                    </div>
                </div>
            </div>
        </div>
    </div>
)