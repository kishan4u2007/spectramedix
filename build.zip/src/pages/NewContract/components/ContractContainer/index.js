import React from "react";
import "./style.scss";

export default (props) => (
    <div className="container-fluid bg-contract-page p-3">
        <div className="page-title mt-60">
            <div className="w-100">
                {props.title}
            </div>
        </div>
        <div className="row m-0 p-0">
            <div className="col-md-12 m-0 p-0">
                {props.children}
            </div>
        </div>
    </div>
)