import React from "react";
import "./style.scss";

export default ({ header, rows }) => {

    function getRowStyleByHeader(key) {
        const header_index = Object.keys(header)[key]
        const header_style = header[header_index]
        return header_style
    }
    return (
        <div className="flex-1 market-statistics-grid">
            <div className="flex-1 header p-0">
                {Object.keys(header).map((item) =>
                    (
                        <div className="header-item mr-0" style={{ ...header[item].style }}>
                            {!!header[item].checkbox &&
                                <input type="checkbox" className="mr-3" />
                            }
                            {item}
                        </div>
                    )
                )}
            </div>
            {rows.map((item, key) => {
                const rowKeys = Object.values(item);
                return (
                    <div className="flex-1 d-flex row-container">
                        {rowKeys.map((row, lineKey) => {
                            const line = getRowStyleByHeader(lineKey)
                            return (
                                <div className="row-item" style={line.hasOwnProperty("lineStyle") ? line.lineStyle : line.style}>
                                    {row}
                                </div>
                            )
                        })}
                    </div>
                )
            })
            }

            {/* <div className="flex-1 row-grid p-0">
                {rows.map((item, key) => {
                    const rowKeys = Object.values(item);
                    return rowKeys.map((row, lineKey) => {
                        const line = getRowStyleByHeader(lineKey)
                        return (
                            <div className="row-item" style={line.hasOwnProperty("lineStyle") ? line.lineStyle : line.style}>
                                {row}
                            </div>
                        )
                    })
                })}
            </div> */}
        </div>
    )
}