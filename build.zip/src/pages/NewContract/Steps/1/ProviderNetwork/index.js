import React from "react";
import "./style.scss";
import CustomLabel from "components/CustomLabel";
import CustomSelect from "components/CustomSelect";
import CustomButton from "components/CustomButton";
import AddNewNetwork from "./AddNewNetwork";
import IconProvider from "components/IconProvider";
import { faPlusSquare, faPen, faTrashAlt, faEllipsisV } from '@fortawesome/free-solid-svg-icons'
import Sortable from "components/Grid/components/sortable";
import BoxInput from "components/BoxInput";
import { Link } from "react-router-dom";
import mask from 'jquery-mask-plugin';
import $ from "jquery";
import _ from "lodash";

class ProviderNetwork extends React.Component {
    state = {
        modalAddNetwork: false,
    }

    componentDidMount() {
        $(document).ready(function () {
            $('.practice-tin').mask('00-0000000');
            $('.tin-container.box-input').mask('00-0000000');
        });
    }

    render() {

        const { step, nested_step, menu, continueSteps } = this.props;

        return (
            <div className="form-group row p-4 provider-network">
                {!!this.state.modalAddNetwork &&
                    <AddNewNetwork
                        title={"Add New Network"}
                        open={this.state.modalAddNetwork}
                        onClose={() => this.setState({ modalAddNetwork: !this.state.modalAddNetwork })}
                    />
                }
                <div className="col-md-12">
                    <div className="label-container">
                        <CustomLabel title={"Provider Network Name"} />
                    </div>
                    <div className="row w-100">
                        <div className="col-sm-4">
                            <CustomSelect
                                options={[1, 2, 3, 4, 5].map((i) => { return { value: i } })}
                                selected={null}
                                onChange={(value) => ""}
                            />
                        </div>
                        <div className="add-new-network d-flex align-items-center" onClick={() => this.setState({ modalAddNetwork: !this.state.modalAddNetwork })}>
                            Add New Network
                        </div>
                    </div>
                </div>
                <div className="col-md-12">
                    <div className="table-container my-2">
                        <div className="p-0 m-0 table-header pl-4">
                            <div className="flex-1">
                                Provider Network Name 1
                            </div>
                            <div className="flex-1">
                                <div className="row justify-content-end">
                                    <IconProvider
                                        tool={true}
                                        tool_id={"add"}
                                        tool_text={"Add"}
                                        type="fa"
                                        icon={faPlusSquare}
                                        onClick={() => ""}
                                    />
                                    <IconProvider
                                        tool={true}
                                        tool_id={"edit"}
                                        tool_text={"Edit"}
                                        type="fa"
                                        icon={faPen}
                                        style={{
                                            marginLeft: "20px"
                                        }}
                                    />
                                    <IconProvider
                                        tool={true}
                                        tool_id={"delete"}
                                        tool_text={"Delete"}
                                        type="fa"
                                        icon={faTrashAlt}
                                        onClick={() => ""}
                                        style={{
                                            marginRight: "20px",
                                            marginLeft: "20px"
                                        }}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="row p-0 m-0 row-header">
                            <div className="d-flex align-items-center px-2">
                                <input type="checkbox" aria-label="Checkbox for following text input" className="check" />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                <Sortable child={"Status"} />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                <Sortable child={"Practice TIN"} />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                <Sortable child={"Patient Name"} />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                <Sortable child={"Practice Specia lity Code"} />
                            </div>
                            <div className="d-flex mx-xl-3 mx-lg-2 align-items-center icon-options" />
                        </div>
                        <div className="p-0 m-0 row-container">
                            <div className="d-flex align-items-center px-2">
                                <input
                                    type="checkbox"
                                    aria-label="Checkbox for following text input"
                                    className="check"
                                />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2 d-flex">
                                <div className="separator-table true" /> Active
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2 practice-tin">
                                463465037
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                xxxxxxxxxx
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                xxxxxxxxxx
                            </div>
                            <div className="d-flex mx-xl-3 mx-lg-2 align-items-center icon-options">
                                <IconProvider
                                    tool={true}
                                    tool_id={"options"}
                                    tool_text={"Options"}
                                    type="fa"
                                    icon={faEllipsisV}
                                    style={{ color: "#929292" }}
                                />
                            </div>
                        </div>
                        <div className="p-0 m-0 row-container">
                            <div className="d-flex align-items-center px-2">
                                <input
                                    type="checkbox"
                                    aria-label="Checkbox for following text input"
                                    className="check"
                                />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2 d-flex">
                                <div className="separator-table true" /> Active
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2 practice-tin">
                                463465037
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                xxxxxxxxx
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                xxxxxxxxxx
                            </div>
                            <div className="d-flex mx-xl-3 mx-lg-2 align-items-center icon-options">
                                <IconProvider
                                    tool={true}
                                    tool_id={"options"}
                                    tool_text={"Options"}
                                    type="fa"
                                    icon={faEllipsisV}
                                    style={{ color: "#929292" }}
                                />
                            </div>
                        </div>
                    </div>

                    <div className="table-container">
                        <div className="p-0 m-0 table-header pl-4">
                            <div className="flex-1">
                                Provider Network Name 1
                            </div>
                            <div className="flex-1">
                                <div className="row justify-content-end">
                                    <IconProvider
                                        tool={true}
                                        tool_id={"add"}
                                        tool_text={"Add"}
                                        type="fa"
                                        icon={faPlusSquare}
                                        onClick={() => ""}
                                    />
                                    <IconProvider
                                        tool={true}
                                        tool_id={"edit"}
                                        tool_text={"Edit"}
                                        type="fa"
                                        icon={faPen}
                                        style={{
                                            marginLeft: "20px"
                                        }}
                                    />
                                    <IconProvider
                                        tool={true}
                                        tool_id={"delete"}
                                        tool_text={"Delete"}
                                        type="fa"
                                        icon={faTrashAlt}
                                        onClick={() => ""}
                                        style={{
                                            marginRight: "20px",
                                            marginLeft: "20px"
                                        }}
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="row p-0 m-0 row-header">
                            <div className="d-flex align-items-center px-2">
                                <input type="checkbox" aria-label="Checkbox for following text input" className="check" />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                <Sortable child={"Status"} />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                <Sortable child={"Practice TIN"} />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                <Sortable child={"Patient Name"} />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2">
                                <Sortable child={"Practice Specia lity Code"} />
                            </div>
                            <div className="d-flex mx-xl-3 mx-lg-2 align-items-center icon-options" />
                        </div>
                        <div className="p-0 m-0 row-container">
                            <div className="d-flex align-items-center px-2">
                                <input
                                    type="checkbox"
                                    aria-label="Checkbox for following text input"
                                    className="check"
                                />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2 d-flex">
                                <div className="separator-table true" /> Active
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2 box-ctn tin-container">
                                <BoxInput value={463465037} />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2 box-ctn">
                                <BoxInput />
                            </div>
                            <div className="flex-1 mx-xl-3 mx-lg-2 box-ctn">
                                <BoxInput />
                            </div>
                            <div className="d-flex mx-xl-3 mx-lg-2 align-items-center icon-options">
                                <IconProvider
                                    tool={true}
                                    tool_id={"options"}
                                    tool_text={"Options"}
                                    type="fa"
                                    icon={faEllipsisV}
                                    style={{ color: "#929292" }}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row mt-5 mb-0">
                        <div class="col-sm-12 d-flex justify-content-center">
                            <Link to="/" style={{textDecoration: 'initial'}}>
                                <CustomButton title={"Cancel"} disabled={true} className="mDefault"/>
                            </Link>

                            <CustomButton className="mDefault" disabled={step == 1 && nested_step == 0} title={"Back"} />

                            <CustomButton className="mDefault" title={"Continue"} onClick={() => this.props.btnContinue()} />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default ProviderNetwork;