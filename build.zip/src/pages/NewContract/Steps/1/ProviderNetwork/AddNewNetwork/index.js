import React from "react";
import Modal from "../../../../components/Modal";
import "./style.scss";

export default class AddNewnetwork extends React.Component {

    state = {
        network: ""
    }

    render() {
        return (
            <Modal {...this.props}>
                <div className="add-new-network-modal">
                    <div className="input-box my-5" style={{ position: "relative" }}>
                        <input
                            class="form-control height-default select-with-label-right"
                            placeholder="Enter New Network Name"
                            value={this.state.network}
                            onChange={(val) => this.setState({ network: val.target.value })}
                        />
                    </div>
                    <div className="my-5 d-flex justify-content-center bottom_buttons">
                        <div className="btn" style={{ backgroundColor: "#BDBDBD" }} onClick={() => this.props.onClose()}>
                            Cancel
                        </div>
                        <div className="btn" style={{ backgroundColor: "#78D779" }}>
                            Save
                        </div>
                    </div>
                </div>
            </Modal>
        )
    }
}