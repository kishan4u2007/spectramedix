import React from "react";
import "./style.scss";
import CustomLabel from "components/CustomLabel";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faPlusSquare, faPen, faTrashAlt, faEllipsisV } from '@fortawesome/free-solid-svg-icons'
import IconProvider from "components/IconProvider";
import CustomButton from "components/CustomButton"
import CustomSelect from "components/CustomSelect"
import CustomSelectCheckBox from "components/CustomSelectCheckBox"
import BoxInput from "components/BoxInput";

import _ from "lodash";
import { Link } from "react-router-dom";

export default ({ step, nested_step, contract, onChange, btnContinue, match, location }) => {

   console.log(location);
   

    function addGeography() {
        let geography_region = { ...contract.geography_region };
        const item = geography_region.items[0];
        const newRegion = Object.keys(item).reduce((initial, value) => {
            initial[value] = null;
            return initial;
        }, {})
        geography_region.items.push(newRegion);
        onChange("geography_region", geography_region)
    }

    function changeGeography(key, attrName, value) {
        let geography_region = { ...contract.geography_region };
        geography_region.items[key][attrName] = value;
        onChange("geography_region", geography_region)
    }

    function toogleCheck(key) {
        let geography_region = { ...contract.geography_region };
        geography_region.checkeds = geography_region.checkeds.includes(key) ? geography_region.checkeds.filter((itm) => itm != key) : [...geography_region.checkeds, key]
        onChange("geography_region", geography_region)
    }

    function deleteGeography() {
        let geography_region = { ...contract.geography_region };
        geography_region.checkeds = [];
        geography_region.items = geography_region.items.filter((itm, key) => {
            if (key == 0) return itm;
            return !contract.geography_region.checkeds.includes(key)
        });
        onChange("geography_region", geography_region)
    }

    function onSelectChange(key, value) {
        onChange(key, value)
    }

    function onMultiSelectChange(key, value, bool) {
        if (!contract[key]) {
            onSelectChange(key, [value])
        } else if (!bool) {
            onSelectChange(key, contract[key].filter((item) => item.value != value.value))
        } else {
            onSelectChange(key, [...contract[key], value])
        }
    }

 
    

    return (
        <div className="form-group row py-4 px-3 market-parameters">
            <div className="col-sm-3">
                <div className="label-container">
                    <CustomLabel title={"Lines of Business (LOB)"} required />
                </div>
                <CustomSelectCheckBox
                    options={[{ value: "Commercial" }, { value: "Medicare Advantage" }, { value: "Medicare" }, { value: "Medicaid" },]}
                    selecteds={contract.lob}
                    onChange={(bool, value) => onMultiSelectChange("lob", value, bool)}
                />
            </div>
            <div className="col-sm-3">
                <div className="label-container">
                    <CustomLabel title={"Group Type"} required />
                </div>
                <CustomSelectCheckBox
                    options={[{
                        value: "Individual",
                    }, {
                        value: "valueJumbo"
                    }, {
                        value: "Large Group"
                    }, {
                        value: "National"
                    }, {
                        value: "Small"
                    }]}
                    selecteds={contract.group_type}
                    onChange={(bool, value) => onMultiSelectChange("group_type", value, bool)}
                />
            </div>
            <div className="col-sm-3">
                <div className="label-container">
                    <CustomLabel title={"Found Type"} />
                </div>
                <CustomSelectCheckBox
                    options={[
                        {
                            value: "Fully-Insured",
                        },
                        {
                            value: "Minimum Premium",
                        },
                        {
                            value: "Self-Insured"
                        },
                    ]}
                    selecteds={contract.funding_type}
                    onChange={(bool, value) => onMultiSelectChange("funding_type", value, bool)}
                />
            </div>
            <div className="col-sm-3">
                <div className="label-container">
                    <CustomLabel title={"Product Type"} required />
                </div>
                <CustomSelectCheckBox
                    options={[
                        { value: "EPO" },
                        { value: "Indemnity" },
                        { value: "HMO" },
                        { value: "PPO" }
                    ]}
                    selecteds={contract.product_type}
                    onChange={(bool, value) => onMultiSelectChange("product_type", value, bool)}
                />
            </div>
            <div className="col-sm-3 mt-5">
                <div className="label-container">
                    <CustomLabel title={"Network"} required />
                </div>
                <CustomSelectCheckBox
                    options={[
                        { value: "Network Blue" },
                        { value: "Select BlueChoice" }
                    ]}
                    selecteds={contract.network}
                    onChange={(bool, value) => onMultiSelectChange("network", value, bool)}
                />
            </div>
            <div className="col-sm-3 mt-5">
                <div className="label-container">
                    <CustomLabel title={"Medical  Stop Loss Limit"} />
                </div>
                <div className="height-default">
                    <BoxInput value={contract.medical_stop} onChange={(val) => onChange("medical_stop", val)} />
                </div>
            </div>
            <div className="col-sm-3 mt-5">
                <div className="label-container">
                    <CustomLabel title={"Drug Stop Loss Limit"} />
                </div>
                <div className="height-default">
                    <BoxInput value={contract.drug_stop_loss} onChange={(val) => onChange("drug_stop_loss", val)} />
                </div>
            </div>
            <div className="col-sm-12 mt-5">
                <div className="table-container">
                    <div className="p-0 m-0 table-header pl-4">
                        <div className="flex-1">
                            Add Geography Region
                        </div>
                        <div className="flex-1">
                            <div className="row justify-content-end">
                                <IconProvider
                                    tool={true}
                                    tool_id={"add"}
                                    tool_text={"Add"}
                                    type="fa"
                                    icon={faPlusSquare}
                                    onClick={() => addGeography()}
                                />
                                <IconProvider
                                    tool={true}
                                    tool_id={"edit"}
                                    tool_text={"Edit"}
                                    type="fa"
                                    icon={faPen}
                                    style={{
                                        marginLeft: "20px"
                                    }}
                                />
                                <IconProvider
                                    tool={true}
                                    tool_id={"delete"}
                                    tool_text={"Delete"}
                                    type="fa"
                                    icon={faTrashAlt}
                                    onClick={() => deleteGeography()}
                                    style={{
                                        marginRight: "20px",
                                        marginLeft: "20px"
                                    }}
                                />
                            </div>
                        </div>
                    </div>
                    <div className="row p-0 m-0 row-header">
                        <div className="d-flex align-items-center px-2">
                            <input type="checkbox" aria-label="Checkbox for following text input" className="check" checked={contract.geography_region.all} onChange={() => onChange("geography_region",
                                {
                                    ...contract.geography_region,
                                    all: !contract.geography_region.all,
                                    checkeds: [...contract.geography_region.items]
                                }
                            )} />
                        </div>
                        <div className="flex-1 mx-xl-3 mx-lg-2">
                            <CustomLabel title={"State"} />
                        </div>
                        <div className="flex-1 mx-xl-3 mx-lg-2">
                            <CustomLabel title={"Region"} />
                        </div>
                        <div className="flex-1 mx-xl-3 mx-lg-2">
                            <CustomLabel title={"Country"} />
                        </div>
                        <div className="flex-1 mx-xl-3 mx-lg-2">
                            <CustomLabel title={"ZIP Code"} />
                        </div>
                        <div className="d-flex mx-xl-3 mx-lg-2 align-items-center icon-options" />
                    </div>
                    {contract.geography_region.items.map((item, key) => {
                        return (
                            <div className="p-0 m-0 row-container">
                                <div className="d-flex align-items-center px-2">
                                    <input
                                        type="checkbox"
                                        aria-label="Checkbox for following text input"
                                        className="check"
                                        checked={contract.geography_region.checkeds.includes(key)}
                                        onChange={() => toogleCheck(key)}
                                    />
                                </div>
                                <div className="flex-1 mx-xl-3 mx-lg-2">
                                    <CustomSelect
                                        options={[1, 2, 3, 4, 5].map((i) => { return { value: i } })}
                                        selected={item.state}
                                        onChange={(value) => changeGeography(key, "state", value)}
                                    />
                                </div>
                                <div className="flex-1 mx-xl-3 mx-lg-2">
                                    <CustomSelect
                                        options={[1, 2, 3, 4, 5].map((i) => { return { value: i } })}
                                        selected={item.region}
                                        onChange={(value) => changeGeography(key, "region", value)}
                                    />
                                </div>
                                <div className="flex-1 mx-xl-3 mx-lg-2">
                                    <CustomSelect
                                        options={[1, 2, 3, 4, 5].map((i) => { return { value: i } })}
                                        selected={item.country}
                                        onChange={(value) => changeGeography(key, "country", value)}
                                    />
                                </div>
                                <div className="flex-1 mx-xl-3 mx-lg-2">
                                    <CustomSelect
                                        options={[1, 2, 3, 4, 5].map((i) => { return { value: i } })}
                                        selected={item.zip_code}
                                        onChange={(value) => changeGeography(key, "zip_code", value)}
                                    />
                                </div>
                                <div className="d-flex mx-xl-3 mx-lg-2 align-items-center icon-options">
                                    <IconProvider
                                        tool={true}
                                        tool_id={"options"}
                                        tool_text={"Options"}
                                        type="fa"
                                        icon={faEllipsisV}
                                        style={{ color: "#929292" }}
                                    />
                                </div>
                            </div>
                        )
                    })}
                </div>
                <div className="row my-5">
                    <div class="col-sm-12 d-flex justify-content-center">
                        <Link to="/" style={{ textDecoration: 'initial' }}>
                            <CustomButton title={"Cancel"} disabled={true} className="mDefault" />
                        </Link>

                        <CustomButton className="mDefault" disabled={step == 1 && nested_step == 0} title={"Back"} />

                        <CustomButton className="mDefault" title={"Continue"} onClick={() => btnContinue()} />
                    </div>
                </div>
            </div>
        </div>
    )
}