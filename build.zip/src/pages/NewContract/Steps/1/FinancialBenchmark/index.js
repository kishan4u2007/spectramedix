import React from "react";
import "./style.scss";
import CustomLabel from "components/CustomLabel";
import CustomSelect from "components/CustomSelect";
import { Link } from "react-router-dom";
import CustomButton from "components/CustomButton";
import IconProvider from "components/IconProvider";
import { faArrowUp, faArrowDown, faFileAlt } from '@fortawesome/free-solid-svg-icons'
import Grid from "../../../components/Grid"
import { header_market_statistics, row_market_statistics } from "./grid_setup/index";
import _ from "lodash";
import * as actionsContract from "redux/reducers/contractReducer";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";

class FinancialBenchmark extends React.Component {

    state = {

    }

    render() {
        const { menu, nested_step, step, continueSteps } = this.props;
        return (
            <div className="form-group row mb-0 p-4 financial-benchmark">
                <div className="row w-100 m-0 px-2">
                    <div className="col-md-6 left-title page-title p-0 m-0">
                        Benchmark Fiscal Period
                    </div>
                    <div className="col-md-6 text-right page-title">
                        <div className="row">
                            <div className="col-md-6 text-right page-title">
                                Paid Date Range:
                                </div>
                            <div className="col-md-6 text-right page-title date">
                                <div className="row">
                                    Jan 2015 - Dec 2019
                                   </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="mx-2 my-2 separator" />
                <div className="btn-top-container">
                    <div className="flex-1 mt-3 mx-3 box-select-item">
                        <div className="label-container">
                            <CustomLabel title={"Fiscal Period Start Month (1st Day of Month)"} />
                        </div>
                        <CustomSelect
                            options={[
                                { value: "January" }, { value: "February" }, { value: "March" }, { value: "April" }, { value: "May" },
                                { value: "June" }, { value: "July" }, { value: "August" }, { value: "September" }, { value: "October" },
                                { value: "November" }, { value: "December" },
                            ]}
                            selected={this.props.contract.fiscal_period_start}
                            onChange={(value) => this.props.onChange("fiscal_period_start", value)}
                        />
                    </div>
                    <div className="flex-1  mt-3 mx-3 box-select-item">
                        <div className="label-container">
                            <CustomLabel title={"Length of Period"} />
                        </div>
                        <CustomSelect
                            options={[
                                { value: "1 Month" }, { value: "2 Months" }, { value: "3 Months" }, { value: "4 Months" }, { value: "5 Months" },
                                { value: "6 Months" }, { value: "7 Months" }, { value: "8 Months" }, { value: "9 Months" }, { value: "10 Months" },
                                { value: "11 Months" }, { value: "12 Months" },
                            ]}
                            selected={this.props.contract.length_of_period}
                            onChange={(value) => this.props.onChange("length_of_period", value)}
                        />
                    </div>
                    <div className="flex-1  mt-3 mx-3 box-select-item">
                        <div className="label-container">
                            <CustomLabel title={"Runout Period"} />
                        </div>
                        <CustomSelect
                            options={[
                                { value: "1 Month" }, { value: "2 Months" }, { value: "3 Months" }, { value: "4 Months" }, { value: "5 Months" },
                                { value: "6 Months" }
                            ]}
                            selected={this.props.contract.runout_period}
                            onChange={(value) => this.props.onChange("runout_period", value)}
                        />
                    </div>
                    <div className="flex-1  mt-3 d-flex">
                        <button type="button" className="btn btn-success btn-calculate">
                            Calculate
                        </button>
                    </div>
                </div>
                <div className="py-5 w-100">
                    <div className="col-md-12 px-md-4">
                        <div className="row market-statistics-header">
                            <div className="col-sm-8 d-flex align-items-center">
                                Market Statistics (Medical)
                            </div>
                            <div className="col-sm-4 d-flex justify-content-end align-items-center">
                                <IconProvider
                                    type="fa"
                                    icon={faArrowDown}
                                />
                            </div>
                        </div>
                        <div className="row market-statistics-header-icons justify-content-end my-3 mx-3">
                            <IconProvider
                                type="fa"
                                icon={faFileAlt}
                                style={{
                                    color: "#979797",
                                }}
                            />
                            <IconProvider
                                type="fa"
                                icon={faFileAlt}
                                style={{
                                    color: "#979797",
                                    marginLeft: "20px"
                                }}
                            />
                        </div>
                        <Grid header={header_market_statistics} rows={row_market_statistics} />
                        <div className="row mx-0">
                            <div className="label-container historic-medical-label col-sm-12 px-0">
                                <CustomLabel title={"Historic Medical Monthly Trend Rate for Selected Period"} />
                            </div>
                            <div className="col-sm-8 col-md-5 historic-medical-box">

                            </div>
                        </div>
                    </div>
                    <div className="col-md-12 px-md-4 mt-5">
                        <div className="row market-statistics-header">
                            <div className="col-sm-8 d-flex align-items-center">
                                Market Statistics (Drugs)
                            </div>
                            <div className="col-sm-4 d-flex justify-content-end align-items-center">
                                <IconProvider
                                    type="fa"
                                    icon={faArrowDown}
                                />
                            </div>
                        </div>
                        <div className="row market-statistics-header-icons justify-content-end my-3 mx-3">
                            <IconProvider
                                type="fa"
                                icon={faFileAlt}
                                style={{
                                    color: "#979797",
                                }}
                            />
                            <IconProvider
                                type="fa"
                                icon={faFileAlt}
                                style={{
                                    color: "#979797",
                                    marginLeft: "20px"
                                }}
                            />
                        </div>
                        <Grid header={header_market_statistics} rows={row_market_statistics} />
                        <div className="row mx-0">
                            <div className="label-container historic-medical-label col-sm-12 px-0">
                                <CustomLabel title={"Historic Drug Monthly Trend Rate for Selected Period"} />
                            </div>
                            <div className="col-sm-8 col-md-5 historic-medical-box">

                            </div>
                        </div>
                    </div>
                    <div className="row mt-5 mb-0">
                        <div class="col-sm-12 d-flex justify-content-center">
                            <Link to="/" style={{ textDecoration: 'initial' }}>
                                <CustomButton title={"Cancel"} disabled={true} className="mDefault" />
                            </Link>

                            <CustomButton className="mDefault" disabled={step == 1 && nested_step == 0} title={"Back"} />

                            <CustomButton className="mDefault" title={"Continue"} onClick={() => this.props.btnContinue()} />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

const mapDispatchToProps = dispatch => {
    return {
        actionsContract: bindActionCreators(actionsContract, dispatch)
    }
}

const mapStateToProps = (state) => {
    return {
        contract: state.contractReducer.contract
    }
}


export default connect(mapStateToProps, mapDispatchToProps)(FinancialBenchmark);