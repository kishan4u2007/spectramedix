export const header_market_statistics = {
    "Statistics": {
        style: {
            flex: 2,
            borderRight: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            marginRight: "10px",
        },
        lineStyle: {
            flex: 2,
            borderRight: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            // marginRight: "10px",
        }
    },
    "Period 1": {
        style: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        lineStyle: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        checkbox: true,
    },
    "Period 2": {
        style: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        lineStyle: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        checkbox: true,
    },
    "Period 3": {
        style: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        lineStyle: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        checkbox: true,
    },
    "Period 4": {
        style: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        lineStyle: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        checkbox: true,
    },
    "Period 5": {
        style: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        lineStyle: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        checkbox: true,
    },
    "Selected Period Total": {
        style: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 2,
            backgroundColor: "#E0E0E0"
        },
        lineStyle: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 2,
            textAlign: "right"
        },
    }
}

export const row_market_statistics = [{
    incurred_date_range: "Incurred Date Range",
    period_1: "01/19 - 12/19",
    period_2: "02/19 - 12/19",
    period_3: "03/19 - 12/19",
    period_4: "04/19 - 12/19",
    period_5: "05/19 - 12/19",
    period_6: "05/19 - 12/19",
},
{
    incurred_date_range: "Incurred Date Range",
    period_1: "01/19 - 12/19",
    period_2: "02/19 - 12/19",
    period_3: "03/19 - 12/19",
    period_4: "04/19 - 12/19",
    period_5: "05/19 - 12/19",
    period_6: "05/19 - 12/19",
},
]