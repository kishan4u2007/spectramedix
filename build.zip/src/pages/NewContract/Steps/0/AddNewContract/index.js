import React from "react";
import Modal from "../../../components/Modal";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faTrashAlt, faPlusCircle } from '@fortawesome/free-solid-svg-icons'

export default class AddNewContract extends React.Component {

    state = {
        contract_group: [{ value: "" }]
    }

    render() {
        return (
            <Modal {...this.props}>
                <div className="add-new-contract-modal">
                    {this.state.contract_group.map((contract, index) =>
                        <div className="input-box my-3" style={{ position: "relative" }}>
                            <input
                                class="form-control height-default select-with-label-right"
                                placeholder="Enter New Contract Group"
                                value={contract.value}
                                onChange={(val) => {
                                    const newState = [...this.state.contract_group].map((item, key) => {
                                        if (key == index) {
                                            return { ...item, value: val.target.value }
                                        }
                                        return item;
                                    })
                                    this.setState({ contract_group: newState })
                                }}
                            />
                            {index > 0 &&
                                <FontAwesomeIcon icon={faTrashAlt} style={{
                                    width: "22px",
                                    height: "22px",
                                    marginRight: "20px",
                                    cursor: "pointer",
                                    position: "absolute",
                                    top: "10px",
                                    right: "-55px",
                                    color: "#838383"
                                }}
                                    onClick={() => this.setState({ contract_group: this.state.contract_group.filter((item, key) => key != index) })}
                                />
                            }
                        </div>
                    )}
                    <div className="my-3 d-flex justify-content-center bottom_buttons">
                        <div className="btn" style={{ backgroundColor: "#BDBDBD", flex: 1 }} onClick={() => this.props.onClose()}>
                            Cancel
                            </div>
                        <div className="btn" style={{ backgroundColor: "#78D779", flex: 2, margin: '0px 4px', display: 'flex' }} onClick={() => this.setState({ contract_group: [...this.state.contract_group, { name: "" }] })}>
                            <FontAwesomeIcon icon={faPlusCircle} style={{
                                width: "18px",
                                height: "18px",
                                marginRight: "10px"
                            }} />
                            <div className="text-left">Add New Contract Group</div>
                        </div>
                        <div className="btn" style={{ backgroundColor: "#78D779", flex: 1 }} onClick={() => this.props.save(this.state.contract_group)}>
                            Save
                        </div>
                    </div>
                </div>
            </Modal>
        )
    }
}