import React from "react";
import { PageContainer } from "components/Partials"
import "./style.scss";
import { Link } from "react-router-dom";
import AddNewContract from "./AddNewContract"

import * as actionsContract from "redux/reducers/contractReducer";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import CustomButton from "components/CustomButton"
import CustomSelect from "components/CustomSelect"
class Step0 extends React.Component {

    state = {
        modalNewContract: false,
    }

    render() {
        return (
            <>
                {!!this.state.modalNewContract &&
                    <AddNewContract
                        save={(val) => {
                            this.props.actionsContract.create_new_contract_group(val)
                            this.setState({ modalNewContract: !this.state.modalNewContract })
                        }}
                        title={"Add New Contract Group"}
                        open={this.state.modalNewContract}
                        onClose={() => this.setState({ modalNewContract: !this.state.modalNewContract })}
                    >

                    </AddNewContract>
                }
                <div className="w-100 flex-column d-flex align-items-center">
                    <div class="form-group col-md-8">
                        <div className="mb-3 d-flex div-label-input">
                            <div className="pDiv">
                                <label className="label-default">Client Type</label>
                                <CustomSelect
                                    options={[{ value: "ACO" }, { value: "Health Plan" }, { value: "Health System" }, { value: "PCMH" }, { value: "BH" }]}
                                    selected={this.props.contract.client_type}
                                    onChange={(value) => this.props.actionsContract.changeContract({ ...this.props.contract, client_type: value })}
                                />
                            </div>
                            <div className="sDiv"></div>
                        </div>
                        <div className="mb-3 d-flex div-label-input">
                            <div className="pDiv">
                                <label className="label-default">Contract Group <label className="colorRed">*</label></label>
                                <CustomSelect
                                    options={this.props.contract.contract_group_options}
                                    selected={this.props.contract.contract_group}
                                    onChange={(value) => this.props.actionsContract.changeContract({ ...this.props.contract, contract_group: value })}
                                />
                            </div>
                            <div className="sDiv">
                                <span
                                    className="default-link-router label-link-general"
                                    onClick={() => {
                                        this.setState({ modalNewContract: !this.state.modalNewContract })
                                    }}
                                >
                                    Create New Contract Group
                                </span>
                            </div>
                        </div>
                        <div className="mb-3 d-flex div-label-input">
                            <div className="pDiv">
                                <label className="label-default">Contract Name <label className="colorRed">*</label></label>
                                <input class="form-control height-default select-with-label-right"
                                    value={this.props.contract.contract_name}
                                    onChange={(e) => this.props.actionsContract.changeContract({ ...this.props.contract, contract_name: e.target.value })}
                                />
                            </div>
                            <div className="sDiv">
                                <span to="new-contract-group" className="label-description-general">
                                    <div>Contract Name must be unique </div><div>within a Contract Group.</div>
                                </span>
                            </div>
                        </div>
                        <div className="mb-3 d-flex div-label-input">
                            <div className="pDiv">
                                <label className="label-default">Contract Template <label className="colorRed">*</label></label>
                                <CustomSelect
                                    options={[]}
                                    selected={null}
                                    onChange={(value) => ""}
                                />
                            </div>
                            <div className="sDiv">
                                <Link to="new-contract-group" className="default-link-router label-link-general">
                                    Review Template
                                </Link>
                            </div>
                        </div>
                        <div className="mb-3 d-flex div-label-input">
                            <div className="pDiv">
                                <label className="label-default">Notes </label>
                                <textarea class="form-control" style={{ height: "180px" }}
                                    value={this.props.contract.notes}
                                    onChange={(e) => this.props.actionsContract.changeContract({ ...this.props.contract, notes: e.target.value })}
                                />
                            </div>
                        </div>

                        <div className="row">
                            <div class="col-sm-12 d-flex">
                                <Link to="/" style={{ textDecoration: 'initial', marginRight: 10 }}>
                                    <CustomButton disabled={true} title={"Cancel"} onClick={() => ""} />
                                </Link>
                                <CustomButton title={"Continue"} onClick={() => this.props.actionsContract.changeStep({ step: 1 })} />
                            </div>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        actionsContract: bindActionCreators(actionsContract, dispatch)
    }
}

const mapStateToProps = (state) => {
    return {
        contract: state.contractReducer.contract,
        step: state.contractReducer.step
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Step0)