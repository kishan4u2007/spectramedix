export const header_attributed_population = {
    "Medical Statistics": {
        style: {
            flex: 2,
            borderRight: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            marginRight: "10px",
        },
        lineStyle: {
            flex: 2,
            borderRight: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            // marginRight: "10px",
        }
    },
    "Voluntary": {
        style: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        lineStyle: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        checkbox: true,
    },
    "Purality Algorithm 1": {
        style: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        lineStyle: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        checkbox: true,
    },
    "Purality Algorithm 2": {
        style: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        lineStyle: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 1,
        },
        checkbox: true,
    },
    "Total": {
        style: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 2,
            backgroundColor: "#E0E0E0"
        },
        lineStyle: {
            borderTop: "1px solid #E2E3E8",
            borderBottom: "1px solid #E2E3E8",
            flex: 2,
            textAlign: "right"
        },
    }
}

export const row_market_statistics = [{
    attributed_network_members: "Attributed Network Members",
    voluntary: "<= 99,000,000",
    purality_1: "<= 99,000,000",
    purality_2: "<= 99,000,000",
    total: "<= 99,000,000"
},
{
    attributed_network_members: "Attributed Network Members Months",
    voluntary: "<= 99,000,000",
    purality_1: "<= 99,000,000",
    purality_2: "<= 99,000,000",
    total: "<= 99,000,000"
},
{
    attributed_network_members: "Attributed Network Members Months %",
    voluntary: "<= 99,000,000",
    purality_1: "<= 99,000,000",
    purality_2: "<= 99,000,000",
    total: "<= 99,000,000"
},
{
    attributed_network_members: "Attributed Network Members",
    voluntary: "<= 99,000,000",
    purality_1: "<= 99,000,000",
    purality_2: "<= 99,000,000",
    total: "<= 99,000,000"
},
{
    attributed_network_members: "Total medical expenses",
    voluntary: "<= 99,000,000",
    purality_1: "<= 99,000,000",
    purality_2: "<= 99,000,000",
    total: "<= 99,000,000"
},
{
    attributed_network_members: "Stop Loss Adjustment",
    voluntary: "<= 99,000,000",
    purality_1: "<= 99,000,000",
    purality_2: "<= 99,000,000",
    total: "<= 99,000,000"
},
{
    attributed_network_members: "Stop Loss Adjusted Total medical Exponses",
    voluntary: "<= 99,000,000",
    purality_1: "<= 99,000,000",
    purality_2: "<= 99,000,000",
    total: "<= 99,000,000"
},
{
    attributed_network_members: "Average Risk Score",
    voluntary: "<= 99,000,000",
    purality_1: "<= 99,000,000",
    purality_2: "<= 99,000,000",
    total: "<= 99,000,000"
},
{
    attributed_network_members: "Risk Adjusted Medical PMPM",
    voluntary: "<= 99,000,000",
    purality_1: "<= 99,000,000",
    purality_2: "<= 99,000,000",
    total: "<= 99,000,000"
},
{
    attributed_network_members: "Number of Months In Period",
    voluntary: "<= 99,000,000",
    purality_1: "<= 99,000,000",
    purality_2: "<= 99,000,000",
    total: "<= 99,000,000"
},
]