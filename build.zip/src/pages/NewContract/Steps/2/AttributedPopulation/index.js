import React from "react";
import IconProvider from "components/IconProvider";
import Separator from "components/Separator";
import CustomButton from "components/CustomButton";
import { faPlusCircle, faFile, faSearch, faArrowDown, faFileAlt } from '@fortawesome/free-solid-svg-icons'
import Grid from "../../../components/Grid"
import { Link } from "react-router-dom"
import { header_attributed_population, row_market_statistics } from "./grid_setup/index";
import "./style.scss";

class AttributedPopulation extends React.Component {
    render() {
        return (
            <div className="attributed-population-container p-4">
                <div className="title-page d-flex">
                    <div className="left-title page-title p-0 m-0 flex-1">
                        Provider Network Attributed Population (Medical)
                    </div>
                    <div className="right-title page-title flex-2 d-flex justify-content-end">
                        <div className="flex-1 text-right mr-sm-5">
                            Benchmark Period Incurred Date Rage: Jan 2019 - Dec 2019
                        </div>
                        <div className="d-flex">
                            <IconProvider
                                type="fa"
                                icon={faFile}
                            />
                            <IconProvider
                                type="fa"
                                icon={faFile}
                                style={{
                                    margin: "0px 10px"
                                }}
                            />
                        </div>
                    </div>
                </div>
                <div className="flex-1 my-4">
                    <Grid header={header_attributed_population} rows={row_market_statistics} />
                </div>
                <div className="flex-1 mx-1 my-4">
                    <Separator />
                </div>
                <div className="title-page d-flex">
                    <div className="left-title page-title p-0 m-0 flex-1">
                        Provider Network Attributed Population (Medical)
                    </div>
                    <div className="right-title page-title flex-2 d-flex justify-content-end">
                        <div className="flex-1 text-right mr-sm-5">
                            Benchmark Period Incurred Date Rage: Jan 2019 - Dec 2019
                        </div>
                        <div className="d-flex">
                            <IconProvider
                                type="fa"
                                icon={faFile}
                            />
                            <IconProvider
                                type="fa"
                                icon={faFile}
                                style={{
                                    margin: "0px 10px"
                                }}
                            />
                        </div>
                    </div>
                </div>
                <div className="flex-1 my-4">
                    <Grid header={header_attributed_population} rows={row_market_statistics} />
                </div>
                <div className="flex-1">
                    <div className="row mt-5 mb-0 justify-content-center w-100">
                        <div class="col-sm-2">
                            <Link to="/">
                                <CustomButton title={"Cancel"} disabled={true} />
                            </Link>
                        </div>
                        <div class="col-sm-2">
                            <CustomButton disabled={{}} title={"Back"} />
                        </div>
                        <div class="col-sm-2">
                            <CustomButton title={"Continue"} onClick={() => this.props.btnContinue()} />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default AttributedPopulation;