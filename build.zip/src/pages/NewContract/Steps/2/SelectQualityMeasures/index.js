import React from "react";
import "./style.scss";
import CustomSelect from "components/CustomSelect";
import CustomLabel from "components/CustomLabel";
import CustomButton from "components/CustomButton";
import { Link } from "react-router-dom";
import CustomCheckBox from "components/CustomCheckBox";
import IconProvider from "components/IconProvider";
import { faChevronRight, faChevronLeft } from '@fortawesome/free-solid-svg-icons'

import Separator from "components/Separator";

class SelectQualityMeasures extends React.Component {
    render() {
        return (
            <div className="select-quality-measures-container p-4">
                <div className="d-flex">
                    <div className="selects-container mr-5">
                        <CustomLabel title="Baseline Period" required />
                        <CustomSelect />
                    </div>
                    <div className="selects-container">
                        <CustomLabel title="Baseline Period" required />
                        <CustomSelect />
                    </div>
                </div>
                <div className="d-flex flex-1 my-3">
                    <Separator />
                </div>
                <div className="meassures">
                    <div className="modal-attributes-specialities d-flex">
                        <div className="side flex-1">
                            <div className="title py-3 px-2">
                                List of Measures
                            </div>
                            <div className="boxspecialities">
                                <div className="header-container px-2">
                                    <div className="header py-3 d-flex">
                                        <CustomCheckBox />
                                        <div className="speciality-header flex-1 mx-3">
                                            Source And Measure Names
                                        </div>
                                    </div>
                                </div>
                                <div className="middle-container">
                                    {/* {this.props.attributable_specialities.options.map((opt) => */}
                                    <div className="middle">
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                    </div>
                                    {/* )} */}
                                </div>
                            </div>
                        </div>
                        <div className="separator-middle">
                            <div className="box-arrow">
                                <IconProvider
                                    type="fa"
                                    icon={faChevronLeft}
                                />
                            </div>
                            <div className="box-arrow">
                                <IconProvider
                                    type="fa"
                                    icon={faChevronRight}
                                />
                            </div>
                        </div>
                        <div className="side flex-1">
                            <div className="title py-3 px-2">
                                List of Selected Measures
                            </div>
                            <div className="boxspecialities">
                                <div className="header-container px-2">
                                    <div className="header py-3 d-flex">
                                        <CustomCheckBox />
                                        <div className="speciality-header flex-1 mx-3">
                                            Source and Measure Names
                                        </div>
                                    </div>
                                </div>
                                <div className="middle-container">
                                    {/* {this.props.attributable_specialities.selecteds.map((opt) => */}
                                    <div className="middle">
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                        <div className="middle-item px-2 py-3 d-flex w-100">
                                            <CustomCheckBox checked={false} onToggle={() => " "} />
                                            <div className="speciality-header flex-1 mx-3 d-flex text-item">
                                                HEDIS - Medication Management for People With Asthma
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="flex-1">
                    <div className="row mt-5 mb-0 justify-content-center w-100">
                        <div class="col-sm-2">
                            <Link to="/">
                                <CustomButton title={"Cancel"} disabled={true} />
                            </Link>
                        </div>
                        <div class="col-sm-2">
                            <CustomButton disabled={{}} title={"Back"} />
                        </div>
                        <div class="col-sm-2">
                            <CustomButton title={"Continue"} onClick={() => this.props.btnContinue()} />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default SelectQualityMeasures;