import React, { Component } from 'react';
import IconProvider from "components/IconProvider";
import PopUp from "components/PopUp";
import { connect } from 'react-redux';
import { faArrowUp, faPlusSquare } from '@fortawesome/free-solid-svg-icons'
import BoxInput from "components/BoxInput";

import "./style.scss";

class DefineMeasuresHeight extends Component {

    state = {
        popup_options: false,
    }

    render() {
        return (
            <div className="define-measures-weight p-4">
                <div className="table-container w-100">
                    <div className="table-header w-100 d-flex">
                        <div className="first-item" />
                        <div className="items flex-1">Measure Category</div>
                        <div className="items flex-2">Measure Name</div>
                        <div className="items flex-1 mr">Alternative Measure Name</div>
                        <div className="items flex-1 mr">Measure Weight</div>
                        <div className="items flex-1 mr">Domain</div>
                    </div>
                    <div className="table-row w-100">
                        <div className="row-container d-flex w-100 bb bt">
                            <div className="first-item">
                                <IconProvider icon={faArrowUp} />
                            </div>
                            <div className="items flex-1">HEDIS</div>
                            <div className="items flex-2">Medication Management for People With Asthma</div>
                            <div className="items flex-1 mr">
                                <BoxInput />
                            </div>
                            <div className="items flex-1 mr">
                                <BoxInput />
                            </div>
                            <div className="items flex-1 mr">
                                <BoxInput />
                            </div>
                        </div>
                        <div className="row-box">
                            <div className="d-flex w-100">
                                <div className="first-item">
                                    <IconProvider icon={faArrowUp} />
                                </div>
                                <div className="items flex-1">HEDIS</div>
                                <div className="items flex-2">Medication Management for People With Asthma</div>
                                <div className="items flex-1 mr">
                                    <BoxInput />
                                </div>
                                <div className="items flex-1 mr">
                                    <BoxInput />
                                </div>
                                <div className="items flex-1 mr">
                                    <BoxInput />
                                </div>
                            </div>
                            <div className="table-inside w-100">
                                <div className="radio-container">
                                    <div className="box d-flex">
                                        <div className="radio-button" />
                                        <div className="items ml-3">
                                            Select Standard Medicare Advantage Cut Points (Select using Standard)
                                        </div>
                                    </div>
                                    <div className="box d-flex">
                                        <div className="radio-button" />
                                        <div className="items ml-3">
                                            Enter Custom Cut Points
                                        </div>
                                    </div>
                                    <div className="tier-table w-100">
                                        <div className="tier-header w-100 d-flex">
                                            <div className="tier-item">
                                                Tier
                                            </div>
                                            <div className="tier-item">
                                                Operator
                                            </div>
                                            <div className="tier-item mr-2">
                                                Cut point
                                            </div>
                                            <div className="tier-item mr-2">
                                                Points
                                            </div>
                                            <div className="box-container">
                                                <div className="d-flex justify-content-end">
                                                    <IconProvider icon={faPlusSquare} style={{ color: "#80807E" }} />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="tier-row-container d-flex bb-none">
                                            <div className="tier-item">
                                                1
                                            </div>
                                            <div className="tier-item">
                                                <div className="popup">
                                                    >
                                                    {/* <PopUp /> */}
                                                </div>
                                            </div>
                                            <div className="tier-item mr-2">
                                                <BoxInput />
                                            </div>
                                            <div className="tier-item  mr-2">
                                                <BoxInput />
                                            </div>
                                            <div className="box-container">
                                                <div className="d-flex justify-content-end">
                                                    <IconProvider icon={faPlusSquare} style={{ color: "#80807E" }} />
                                                </div>
                                            </div>
                                        </div>
                                        <div className="tier-row-container d-flex bt-none">
                                            <div className="tier-item">
                                                1
                                            </div>
                                            <div className="tier-item">
                                                <div className="popup">
                                                    >
                                                </div>
                                            </div>
                                            <div className="tier-item mr-2">
                                                <BoxInput />
                                            </div>
                                            <div className="tier-item  mr-2">
                                                <BoxInput />
                                            </div>
                                            <div className="box-container">
                                                <div className="d-flex justify-content-end">
                                                    <PopUp options={["Edit", "Delete"]} />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => ({});

// const mapDispatchToProps = dispatch =>
//   bindActionCreators(Actions, dispatch);

export default connect(
    mapStateToProps,
    // mapDispatchToProps
)(DefineMeasuresHeight);
