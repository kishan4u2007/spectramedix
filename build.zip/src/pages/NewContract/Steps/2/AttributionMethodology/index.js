import React from "react";
import "./style.scss";
import CustomLabel from "components/CustomLabel";
import CustomButton from "components/CustomButton";
import CustomCheckBox from "components/CustomCheckBox";
import BoxInput from "components/BoxInput";
import CustomSelect from "components/CustomSelect";
import AttributesSpecialities from "./AttributesSpecialities";
import Separator from "components/Separator";
import { Link } from "react-router-dom"
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as contractActions from "redux/reducers/contractReducer";

class AttributionMethodology extends React.Component {

    state = {
        attributesSpecialities: false
    };

    onValueChanges = (attrName, value) => {
        let contract = { ...this.props.contract };
        contract[attrName] = { ...value };
        this.props.contractActions.changeContract(contract)
    }

    render() {
        const { step, nested_step } = this.props;
        return (
            <>
                {this.state.attributesSpecialities &&
                    <AttributesSpecialities
                        open={this.state.attributesSpecialities}
                        onClose={() => this.setState({
                            attributesSpecialities: !this.state.attributesSpecialities
                        })}
                        attributable_specialities={this.props.attributable_specialities_1}
                    />
                }
                <div className="attributionMethodology p-4">
                    <div className="col-md-3 p-0 m-0">
                        <CustomLabel title="Include Voluntary Alignment" required={true} />
                        <CustomSelect options={[{ value: "Yes" }, { value: "No" }]} />
                    </div>
                    <div className="separator-container my-4">
                        <Separator />
                    </div>
                    <div className="board-container d-flex">
                        <div className="left-board flex-1">
                            <div className="header">
                                <CustomCheckBox checked={this.props.include_plurality_1.bool} onToggle={(val) => this.onValueChanges("include_plurality_1", { ...this.props.include_plurality_1, bool: val })} />
                                <div className="mx-3">Include Plurality Algorithm 1 (Check to Enable)</div>
                            </div>
                            <div className="board-middle my-3 mx-3">
                                <div className="attribute">
                                    Attributable Services
                                </div>
                                <div className="item-list mb-5">
                                    - - -
                                </div>
                                <div className="attribute" onClick={() => {
                                    this.setState({ attributesSpecialities: true })
                                }}>
                                    Attributable Specialities
                                </div>
                                <div className="item-list mb-5">
                                    - - -
                                </div>
                                <div className="attribute">
                                    Attributable Services
                                </div>
                                <div className="item-list mb-5">
                                    - - -
                                </div>
                                <div className="">
                                    <CustomLabel
                                        title="Plurality Basis"
                                        required={true}
                                    />
                                    <CustomSelect
                                        options={[{ value: "Allowed Amount" }, { value: "Service Count" }]}
                                    />
                                </div>
                                <div className="mt-5 mb-3">
                                    <CustomLabel title="Loopback Period" required={true} />
                                </div>
                                <div className="d-flex">
                                    <CustomLabel title="Start date" required={true} />
                                    <div className="mx-3">
                                        <CustomSelect />
                                    </div>
                                    <div className="mx-3">
                                        <CustomSelect />
                                    </div>

                                    <CustomLabel title="Start date" required={true} />
                                    <div className="mx-3">
                                        <CustomSelect />
                                    </div>
                                    <div className="mx-3">
                                        <CustomSelect />
                                    </div>
                                </div>
                                <div className="mt-5 mb-3">
                                    <CustomLabel title="Attribution Tie-Breaker(s)" required={true} />
                                </div>
                                <div className="d-flex align-items-center tie-breaker">
                                    <div className="tie-title mr-4">
                                        #1
                                    </div>
                                    <div className="flex-1">
                                        <CustomSelect
                                            options={[
                                                { value: "of non-E&M Professional Services" },
                                                { value: "of unique service dates" },
                                                { value: "Most Dollars Spent" },
                                                { value: "Most Recent Service" },
                                                { value: "Alphabetical" },
                                                { value: "Random" }
                                            ]}
                                        />
                                    </div>
                                    <div className="tie-title mx-4">
                                        #2
                                    </div>
                                    <div className="flex-1">
                                        <CustomSelect
                                            options={[
                                                { value: "of non-E&M Professional Services" },
                                                { value: "of unique service dates" },
                                                { value: "Most Dollars Spent" },
                                                { value: "Most Recent Service" },
                                                { value: "Alphabetical" },
                                                { value: "Random" }
                                            ]}
                                        />
                                    </div>
                                    <div className="tie-title mx-4">
                                        #3
                                    </div>
                                    <div className="flex-1">
                                        <CustomSelect
                                            options={[
                                                { value: "of non-E&M Professional Services" },
                                                { value: "of unique service dates" },
                                                { value: "Most Dollars Spent" },
                                                { value: "Most Recent Service" },
                                                { value: "Alphabetical" },
                                                { value: "Random" }
                                            ]}
                                        />
                                    </div>
                                    <div className="tie-title mx-4">
                                        #4
                                    </div>
                                    <div className="flex-1">
                                        <CustomSelect
                                            options={[
                                                { value: "of non-E&M Professional Services" },
                                                { value: "of unique service dates" },
                                                { value: "Most Dollars Spent" },
                                                { value: "Most Recent Service" },
                                                { value: "Alphabetical" },
                                                { value: "Random" }
                                            ]}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="right-board flex-1">
                            <div className="header">
                                <CustomCheckBox
                                    checked={this.props.include_plurality_2.bool}
                                    onToggle={(val) => this.onValueChanges("include_plurality_2", { ...this.props.include_plurality_2, bool: val })}
                                />
                                <div className="mx-3">Include Plurality Algorithm 2 (Check to Enable)</div>
                            </div>
                            <div className="board-middle my-3 mx-3">
                                <div className="attribute">
                                    Attributable Services
                            </div>
                                <div className="item-list mb-5">
                                    - - -
                            </div>
                                <div className="attribute">
                                    Attributable Services
                            </div>
                                <div className="item-list mb-5">
                                    - - -
                            </div>
                                <div className="attribute">
                                    Attributable Services
                            </div>
                                <div className="item-list mb-5">
                                    - - -
                            </div>
                                <div className="">
                                    <CustomLabel
                                        title="Plurality Basis"
                                        required={true}
                                    />
                                    <CustomSelect
                                        options={[{ value: "Allowed Amount" }, { value: "Service Count" }]}
                                    />
                                </div>
                                <div className="mt-5 mb-3">
                                    <CustomLabel title="Loopback Period" required={true} />
                                </div>
                                <div className="d-flex flex-1">
                                    <CustomLabel title="Start date" required={true} />
                                    <div className="mx-3 flex-1">
                                        <CustomSelect />
                                    </div>
                                    <div className="mx-3 flex-1">
                                        <CustomSelect />
                                    </div>

                                    <CustomLabel title="Start date" required={true} />
                                    <div className="mx-3 flex-1">
                                        <CustomSelect />
                                    </div>
                                    <div className="mx-3 flex-1">
                                        <CustomSelect />
                                    </div>
                                </div>
                                <div className="mt-5 mb-3">
                                    <CustomLabel title="Attribution Tie-Breaker(s)" required={true} />
                                </div>
                                <div className="d-flex align-items-center tie-breaker">
                                    <div className="tie-title mr-4">
                                        #1
                                </div>
                                    <div className="flex-1">
                                        <CustomSelect
                                            options={[
                                                { value: "of non-E&M Professional Services" },
                                                { value: "of unique service dates" },
                                                { value: "Most Dollars Spent" },
                                                { value: "Most Recent Service" },
                                                { value: "Alphabetical" },
                                                { value: "Random" }
                                            ]}
                                        />
                                    </div>
                                    <div className="tie-title mx-4">
                                        #2
                                </div>
                                    <div className="flex-1">
                                        <CustomSelect
                                            options={[
                                                { value: "of non-E&M Professional Services" },
                                                { value: "of unique service dates" },
                                                { value: "Most Dollars Spent" },
                                                { value: "Most Recent Service" },
                                                { value: "Alphabetical" },
                                                { value: "Random" }
                                            ]}
                                        />
                                    </div>
                                    <div className="tie-title mx-4">
                                        #3
                                </div>
                                    <div className="flex-1">
                                        <CustomSelect
                                            options={[
                                                { value: "of non-E&M Professional Services" },
                                                { value: "of unique service dates" },
                                                { value: "Most Dollars Spent" },
                                                { value: "Most Recent Service" },
                                                { value: "Alphabetical" },
                                                { value: "Random" }
                                            ]}
                                        />
                                    </div>
                                    <div className="tie-title mx-4">
                                        #4
                                </div>
                                    <div className="flex-1">
                                        <CustomSelect
                                            options={[
                                                { value: "of non-E&M Professional Services" },
                                                { value: "of unique service dates" },
                                                { value: "Most Dollars Spent" },
                                                { value: "Most Recent Service" },
                                                { value: "Alphabetical" },
                                                { value: "Random" }
                                            ]}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="row my-5 justify-content-center w-100">
                        <div class="col-sm-2">
                            <Link to="/">
                                <CustomButton title={"Cancel"} disabled={true} />
                            </Link>
                        </div>
                        <div class="col-sm-2">
                            <CustomButton disabled={step == 1 && nested_step == 0} title={"Back"} />
                        </div>
                        <div class="col-sm-2">
                            <CustomButton title={"Continue"} onClick={() => this.props.btnContinue()} />
                        </div>
                    </div>
                </div>
            </>
        )
    }
}

const mapStateToProps = state => ({
    contract: state.contractReducer.contract,
    attributable_specialities_1: state.contractReducer.contract.include_plurality_1.attributable_specialities,
    attributable_specialities_2: state.contractReducer.contract.include_plurality_2.attributable_specialities,
    include_plurality_1: state.contractReducer.contract.include_plurality_1,
    include_plurality_2: state.contractReducer.contract.include_plurality_2,
});

const mapDispatchToProps = dispatch => ({
    contractActions: bindActionCreators(contractActions, dispatch)
})

export default connect(mapStateToProps, mapDispatchToProps)(AttributionMethodology)