import React from "react";
import "./style.scss";
import CustomModal from "../../../../components/Modal";
import CustomCheckBox from "components/CustomCheckBox";
import IconProvider from "components/IconProvider";
import { faChevronLeft, faChevronRight } from '@fortawesome/free-solid-svg-icons'
import { bindActionCreators } from "redux";
import { connect } from "react-redux";
import * as contractActions from "redux/reducers/contractReducer";

class AttributesSpecialities extends React.Component {

    toggleCheck = val => {
        // let items = this.props.attributable_specialities;
        // this.props.contractActions.changeContract({...this.props.contract, })
    };

    render() {
        return (
            <div className="atributesspecialities-container">
                <CustomModal
                    open={this.props.open}
                    onClose={this.props.onClose}
                >
                    <div className="modal-attributes-specialities d-flex">
                        <div className="side flex-1">
                            <div className="title mb-2">
                                List of All Speciality Code
                            </div>
                            <div className="boxspecialities">
                                <div className="header-container px-2">
                                    <div className="header py-3 d-flex">
                                        <CustomCheckBox checked={false} />
                                        <div className="speciality-header flex-1 mx-3 text-center">
                                            Speciality Code
                                        </div>
                                        <div className="speciality-header flex-1">
                                            Speciality Description
                                        </div>
                                    </div>
                                </div>
                                <div className="middle-container">
                                    {this.props.attributable_specialities.options.map((opt) =>
                                        <div className="middle">
                                            <div className="middle-item mx-2 py-3 d-flex w-100">
                                                <CustomCheckBox checked={opt.selected} onToggle={() => this.toggleCheck(!opt.checked)} />
                                                <div className="speciality-header flex-1 mx-3 d-flex justify-content-center text-item">
                                                    {opt.id}
                                                </div>
                                                <div className="speciality-header flex-1 text-item">
                                                    {opt.name}
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                        <div className="separator-middle">
                            <div className="box-arrow">
                                <IconProvider
                                    type="fa"
                                    icon={faChevronLeft}
                                />
                            </div>
                            <div className="box-arrow">
                                <IconProvider
                                    type="fa"
                                    icon={faChevronRight}
                                />
                            </div>
                        </div>
                        <div className="side flex-1">
                            <div className="title mb-2">
                                List of All Selected Speciality Code
                            </div>
                            <div className="boxspecialities">
                                <div className="header-container px-2">
                                    <div className="header py-3 d-flex">
                                        <CustomCheckBox />
                                        <div className="speciality-header flex-1 mx-3 text-center">
                                            Speciality Code
                                        </div>
                                        <div className="speciality-header flex-1">
                                            Speciality Description
                                        </div>
                                    </div>
                                </div>
                                <div className="middle-container">
                                    {this.props.attributable_specialities.selecteds.map((opt) =>
                                        <div className="middle">
                                            <div className="middle-item mx-2 py-3 d-flex w-100">
                                                <CustomCheckBox />
                                                <div className="speciality-header flex-1 mx-3 d-flex justify-content-center text-item">
                                                    {opt.id}
                                                </div>
                                                <div className="speciality-header flex-1 text-item">
                                                    {opt.name}
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </CustomModal>
            </div>
        )
    }
}

const mapDispatchToProps = dispatch => ({
    contractActions: bindActionCreators(contractActions, dispatch)
})
export default connect(null, mapDispatchToProps)(AttributesSpecialities);