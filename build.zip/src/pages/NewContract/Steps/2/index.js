import React from "react";
import "./style.scss";
import * as actionsContract from "redux/reducers/contractReducer";
import { connect } from "react-redux";
import { bindActionCreators } from "redux";
import { getCurrentStep } from "redux/reducers/contractReducer"
import AttributionMethodology from "./AttributionMethodology";
import AttributedPopulation from "./AttributedPopulation";
import SelectQualityMeasures from "./SelectQualityMeasures";
import DefineMeasuresWeight from "./DefineMeasuresWeight";

class ContractParameters extends React.Component {
    render() {
        return (
            <div className="contract-parameters-container">
                <>
                    {this.props.getCurrentStep.nested_step == 0 &&
                        <AttributionMethodology {...this.props} />
                    }
                    {this.props.getCurrentStep.nested_step == 1 &&
                        <AttributedPopulation {...this.props} />
                    }
                    {this.props.getCurrentStep.nested_step == 2 &&
                        <SelectQualityMeasures {...this.props} />
                    }
                    {this.props.getCurrentStep.nested_step == 3 &&
                        <DefineMeasuresWeight {...this.props} />
                    }
                </>
            </div>
        )
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        actionsContract: bindActionCreators(actionsContract, dispatch)
    }
}

const mapStateToProps = (state) => {
    return {
        menu: state.contractReducer.left_menu_new_contract,
        getCurrentStep: getCurrentStep(state),
        contract: state.contractReducer.contract
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ContractParameters)
