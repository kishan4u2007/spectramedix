import React from "react";
import { Route, Link, Switch } from 'react-router-dom';
export default () => {
    return (
        <>
            <div className="p-5">
                <Link to="/login"><p className="btn-text my-3">- LOGIN</p></Link>
                <Link to="/forgot-password"><p className="btn-text my-3">- FORGOT PASSWORD</p></Link>
                <Link to="/"><p className="btn-text my-3">- HOME</p></Link>
                <Link to="/new-contract"><p className="btn-text my-3">- NEW CONTRACT</p></Link>
            </div>

  
        </>
    )
}