import React from 'react';
import { BrowserRouter, Switch, Route, Redirect, withRouter } from 'react-router-dom';
import Routes from "pages/Routes";
import { Footer } from "components/Partials"
import Navbar from "components/Navbar";
// const SignIn = React.lazy(() => import("pages/SignIn"));
// const Home = React.lazy(() => import("pages/Home"));
// const NewContract = React.lazy(() => import("pages/NewContract"));
// const ForgotPassword = React.lazy(() => import("pages/ForgotPassword"));

import Home from "pages/Home"
import NewContract from "pages/NewContract"
import SignIn from "pages/SignIn"
import ForgotPassword from "pages/ForgotPassword"
import { connect } from 'react-redux';
import MarketParameters from './pages/NewContract/Steps/1/MarketParameters'

function App(props) {
  return (
    // <React.Suspense fallback={<></>}>
    <BrowserRouter>
      <Switch>
        <Route path="/login">
          <SignIn {...props} />
        </Route>
        <Route path="/forgot-password">
          <ForgotPassword />
        </Route>
        <Route path="/routes">
          <Routes />
        </Route>
        <PrivateRoute exact path="/new-contract" user={props.user}>
          <Navbar />
          <NewContract />
          <Footer />
        </PrivateRoute>

        <PrivateRoute exact path="/new-contract/:userId" user={props.user}>
          <Navbar />
          <NewContract />
          <Footer />
        </PrivateRoute>
      
        <PrivateRoute exact path="/" user={props.user}>
          <Navbar />
          <Home />
          <Footer />
        </PrivateRoute>
      </Switch>

    </BrowserRouter>
    // </React.Suspense>
  );
}

const mapStateToProps = state => ({
  user: state.userReducer.user
});

export default connect(mapStateToProps)(App);

const PrivateRoute = ({ children, user, ...rest }) => {
  return (
    <>
      {!!user ?
        <Route {...rest}>
          {children}
        </Route>
        :
        <Redirect to="/login" />
      }
    </>
  );
};