import React from "react";
import "./style.scss";

export default ({ }) => (
    <div className="separator-component" />
)