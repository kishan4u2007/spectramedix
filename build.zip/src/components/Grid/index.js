import React, { Component } from "react";
import "./style.scss";

import ReactDataGrid from 'react-data-grid';

export default ({ columns = [], rows = [], onSort, getCellActions = [] }) => (
    <ReactDataGrid
        columns={columns}
        getCellActions={getCellActions}
        onGridSort={(sortColumn, sortDirection) =>
            !onSort ? false : onSort(sortColumn, sortDirection)
        }
        rowGetter={i => rows[i]}
        rowsCount={rows.length}
        // minHeight={500}
        rowHeight={48}
    />
)