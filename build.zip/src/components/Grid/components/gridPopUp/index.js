import React from "react";
import "./style.scss"
export default ({ lines, onClick }) => (
    <div className="popup-container">
        {lines.map((line, key) =>
            <>
                <div className="line" onClick={() => onClick(line)}>
                    {line}
                </div>
                {key + 1 != lines.length &&
                    <div className="separator" />
                }
            </>
        )
        }
    </div>
)