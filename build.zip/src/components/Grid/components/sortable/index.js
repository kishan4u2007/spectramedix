import React from "react";
import IconProvider from "components/IconProvider";
import { faSort } from '@fortawesome/free-solid-svg-icons'
import "./style.scss";

export default ({ child, onClick = () => "" }) => {
    return (
        <div className="header-item-sortable" onClick={() => onClick()}>
            {child}
            <div className="icon-sort">
                <IconProvider type="fa" icon={faSort} style={{ color: "#97989A", fontSize: "15px" }} />
            </div>
        </div>
    )
}