import React from "react";
import "./style.scss";

export default ({ type = "", placeholder = "", onChange = () => "", value = "" }) => {
    return (
        <div className="box-input-container">
            <input type={type} className="box-input m-0 p-0 h-100 w-100" onChange={e => onChange(e.target.value)} value={value} placeholder={placeholder} />
        </div>
    )
}