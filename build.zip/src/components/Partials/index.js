import React from "react";
import "./style.scss";

export const PageContainer = (props) => (
    <div className="container-fluid bg-page">
        <div className="row page-title px-4">
            {props.title}
        </div>
        <div className="row blank-container">
            {props.children}
        </div>
    </div>
)

export const Footer = (props) => (
    <div className="container-fluid spectra_inc">
        <div className="copy-container">
            SpectraMD USA, Inc. 2010-2019. All rights reserved.
        </div>
    </div>
)