import React from "react";
import "./style.scss";

export default ({ disabled = false, onClick = () => "", title = "", className = "" }) => {

    if (!!disabled) {
        return (
            <button type="button" className={'btn '+className} style={{ backgroundColor: "#BDBDBD", fontSize: "15px" }} onClick={() => onClick()}>
                {title}
            </button>
        )
    }
    return (
        <button type="button" className={'btn '+className} style={{ backgroundColor: "#5A8FD3", fontSize: "15px" }} onClick={() => onClick()}>
            {title}
        </button>
    )
}