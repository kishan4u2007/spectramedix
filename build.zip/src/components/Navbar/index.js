import React, { Component } from "react";
import "./style.scss";
import logo from "assets/images/logo.png";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faHome, } from '@fortawesome/free-solid-svg-icons'
import { Link } from "react-router-dom";
import { connect } from "react-redux";

const NavBar =  ({user}) => (
    <nav className="navbar navbar-light bg-light shadowNav">
        <div className="d-flex">
            <span className="navbar-brand mb-0 h1 client_logo">Client Logo</span>
        </div>
        <div className="menuMobile">MENU</div>
        <div className="d-flex menuDefault">
            <div className="d-flex justify-content-center align-items-center">
                <Link to="/">
                    <FontAwesomeIcon
                        icon={faHome}
                        style={{
                            color: "#9B9B9B",
                            fontSize: "20px",
                            marginLeft: "30px"
                        }} />
                </Link>
                <Link to="/">
                    <FontAwesomeIcon
                        icon={faHome}
                        style={{
                            color: "#9B9B9B",
                            fontSize: "20px",
                            marginLeft: "30px"
                        }} />
                </Link>
                <Link to="/">
                    <FontAwesomeIcon
                        icon={faHome}
                        style={{
                            color: "#9B9B9B",
                            fontSize: "20px",
                            marginLeft: "30px"
                        }} />
                </Link>
                <Link to="/">
                    <FontAwesomeIcon
                        icon={faHome}
                        style={{
                            color: "#9B9B9B",
                            fontSize: "20px",
                            marginLeft: "30px"
                        }} />
                </Link>
            </div>
            <div className="lineVertical"></div>
            <div className="d-flex">
                <div className="divImageHeader">
                    <img src={user.userImage} className="person_icon" />
                    <span className="user-name">
                        {user.name}
                    </span>
                </div>
                <img src={logo} className="logo" />
            </div>
        </div>
    </nav>
)

const mapStateToProps = state => ({
    user: state.userReducer.user
})

export default connect(mapStateToProps)(NavBar);