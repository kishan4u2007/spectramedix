import React from "react";
import "./style.scss";
import { faPlusSquare, faSortDown, faSortUp } from '@fortawesome/free-solid-svg-icons'
import IconProvider from "components/IconProvider";
import onClickOutside from "react-onclickoutside";
import arrowDropDown from "assets/images/arrow-drop-down.png"

class CustomSelect extends React.Component {

    state = {
        open: false
    }

    handleClickOutside = evt => {
        if (this.state.open) { this.setState({ open: false }) }
    };

    render() {
        return (
            <div className="custom-select-container">
                <div className="selected d-flex align-items-center" onClick={() => this.setState({ open: !this.state.open })}>
                    <div className="opt flex-2">
                        {this.props.selected ? this.props.selected.value : "Select..."}
                    </div>
                    <div className="flex-1 d-flex justify-content-end align-items-center">
                        <IconProvider
                            type="img"
                            icon={arrowDropDown}
                            className={"arrow-dropdown"}
                            onClick={() => this.setState({ open: !this.state.open })}
                        />
                    </div>
                </div>
                {this.state.open && !!this.props.options && !!this.props.options.length &&
                    <div className="opt-container">
                        {this.props.options.map((opt) => {
                            return (
                                <div className="opt" onClick={() => {
                                    this.handleClickOutside();
                                    this.props.onChange(opt)
                                }}>
                                    {opt.value}
                                </div>
                            )
                        })}
                    </div>
                }
            </div>

        )
    }
}

export default onClickOutside(CustomSelect);
