import React from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import ReactTooltip from 'react-tooltip'

export default ({ cursor = "pointer", type = "fa", style = {}, icon, tool = false, tool_id = "tool-tip", tool_type = "dark", tool_text = "", onClick, className }, props) => {
    if (type == "fa") {
        return (
            <>
                {!!tool ?
                    <>
                        <div data-tip data-for={tool_id} style={{ ...style }}>
                            <FontAwesomeIcon icon={icon} style={{
                                fontSize: "18px",
                                cursor,
                                ...style,
                            }}
                                onClick={() => !!onClick ? onClick() : ""}
                            />
                        </div>
                        <ReactTooltip id={tool_id} type={tool_type}>
                            <span>{tool_text}</span>
                        </ReactTooltip>
                    </>
                    :
                    <FontAwesomeIcon icon={icon} style={{
                        fontSize: "18px",
                        cursor,
                        ...style,
                    }}
                        onClick={() => !!onClick ? onClick() : ""}
                    />
                }
            </>
        )
    } else {
        return (
            <>
                {!!tool ?
                    <>
                        <div data-tip data-for={tool_id} style={{ ...style }}>
                            <img src={icon}
                                style={{
                                    width: "20px",
                                    height: "20px",
                                    cursor,
                                    ...style,
                                }}
                                className={className}
                                onClick={() => !!onClick ? onClick() : ""}
                            />
                        </div>
                        <ReactTooltip id={tool_id} type={tool_type}>
                            <span>{tool_text}</span>
                        </ReactTooltip>
                    </>
                    :
                    <img src={icon}
                        style={{
                            width: "20px",
                            height: "20px",
                            cursor,
                            ...style,
                        }}
                        className={className}
                        onClick={() => !!onClick ? onClick() : ""}
                    />
                }
            </>
        )
    }
}