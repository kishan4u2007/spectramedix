import React, { Component } from 'react';


export default ({ required, message = "This is a required field!" }) => {

    if (!required) return null;

    return (
        <div className="required-field-label">
            {message}
        </div>
    )
}