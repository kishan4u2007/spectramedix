import React from "react";
import { connect } from "react-redux";
import "./style.scss";

import { StyleSheet, css } from "aphrodite";

import { faAngleDoubleLeft, faAngleDoubleRight, faArrowDown } from '@fortawesome/free-solid-svg-icons'


import IconProvider from "components/IconProvider"

class PaginationTable extends React.Component {
    static defaultProps = {
        actionPerPage: ""
    };

    prevAction = () => {
        const { currentPage } = this.props;

        if (currentPage === 0) return false;

        this.props.changePage(currentPage - 1);
    };

    nextAction = () => {
        const { totalPages, currentPage } = this.props;

        if (currentPage + 1 < totalPages) {
            this.props.changePage(currentPage + 1);
        }
    };

    customAction = val => {
        this.props.changePage(val);
    };

    renderPerPage = () => {
        const { canChangeQtyPage = false, perPage = "50", changeQtyPage } = this.props;
        if (canChangeQtyPage != false) {
            return (
                <div className={css(styles.divSelectPagination)}>
                    <select
                        name="perpage"
                        className={css(styles.paginationSelect)}
                        onChange={e => changeQtyPage(e.currentTarget.value)}
                        value={perPage}
                    >
                        <option
                            selected={perPage == "10" ? true : false}
                            value="10"
                        >
                            10
                        </option>
                        <option
                            value="25"
                            selected={perPage == "25" ? true : false}
                        >
                            25</option>
                        <option
                            value="50"
                            selected={perPage == "50" ? true : false}
                        >
                            50
                        </option>
                        <option
                            selected={perPage == "100" ? true : false}
                            value="100"
                        >
                            100
                        </option>
                    </select>
                    <div className={css(styles.divPaginationArrow)}>
                        <IconProvider
                            type="fa"
                            icon={faArrowDown}
                            onClick={() => { }}
                        />
                    </div>
                </div>
            );
        }
    };

    renderPages = () => {
        const { totalPages = 1, currentPage = 1 } = this.props;
        let pages = [];

        for (let i = 0; i < totalPages; i++) {
            if (i === currentPage) {
                pages.push(
                    <div
                        key={i}
                        className={css(styles.itenPaginationActive)}
                        onClick={() => this.customAction(i)}
                    >
                        {i + 1}
                    </div>
                );
            } else {
                pages.push(
                    <div
                        key={i}
                        className={css(styles.itenPagination)}
                        onClick={() => this.customAction(i)}
                    >
                        {i + 1}
                    </div>
                );
            }
        }

        return pages.map(val => val);
    };

    renderBlock = () => {
        if (this.props.page !== "notes") {
            if (this.props.totalPages > 1) {
                return (
                    <div className={"pagination-box"}>
                        <div className={"text-action"}>
                            First
                        </div>
                        <IconProvider
                            type="fa"
                            icon={faAngleDoubleLeft}
                            style={{ color: "#E5E5E5", fontSize: "15px" }}
                            onClick={() => { }}
                        />
                        {this.renderPages()}
                        <IconProvider
                            type="fa"
                            style={{ color: "#E5E5E5", fontSize: "15px" }}
                            icon={faAngleDoubleRight}
                            onClick={() => { }}
                        />
                        <div className={"text-action"}>
                            Last
                        </div>
                        {this.renderPerPage()}
                    </div>
                );
            } else {
                return (
                    <div className={css(styles.pagination, styles.marginNoPages)}>{this.renderPerPage()}</div>
                );
            }
        } else {
            return <div className={css(styles.pagination)} />;
        }
    };

    render() {
        return this.renderBlock();
    }
}

export default PaginationTable;

const styles = StyleSheet.create({
    alignRight: {
        textAlign: "right"
    },
    icons: {
        marginTop: "5px",
        marginBottom: "5px",
        marginLeft: "40px"
    },
    titlePage: {
        color: "#fff",
        fontSize: "20px",
        textTransform: "uppercase",
        paddingTop: "10px"
    },
    titleSmallPage: {
        color: "#fff",
        fontSize: "14px",
        textTransform: "uppercase",
        paddingTop: "0px"
    },
    ui: {
        modal: {
            bottom: "inherit",
            right: "inherit"
        }
    },
    grid30: {
        width: "30%",
        backgroundColor: "#4E4E4E",
        padding: "15px",
        color: "#fff",
        boxShadow: "inset 0px 6px 15px -8px rgba(0,0,0,0.45)"
    },
    grid70: {
        width: "70%",
        backgroundColor: "#747474",
        padding: "9px",
        color: "#fff",
        display: "flex",
        boxShadow: "inset 0px 6px 15px -8px rgba(0,0,0,0.45)"
    },
    row: {
        paddingBottom: "15px"
    },
    btn: {
        fontSize: "14px",
        fontFamily: "Roboto, sans-serif",
        fontWeight: "400",
        padding: "9px 10px 8px",
        borderRadius: "0",
        width: "100%"
    },
    btnBlue: {
        color: "white",
        background: "#1e88e5",
        height: "38px",
        ":hover": {
            background: "#176ab3"
        }
    },
    select: {
        fontSize: "14px",
        borderRadius: "0px"
    },
    inputsearch: {
        backgroundColor: "transparent !important",
        boxShadow: "transparent !important",
        border: "transparent !important",
        width: "100%",
        fontSize: "14px",
        outline: "none"
    },
    pagination: {
        width: "65%",
        display: 'flex',
        alignItems: 'center'
    },
    divIcons: {
        width: "50%",
        textAlign: "right",
        paddingRight: "4px"
    },
    marginNoPages: {
        marginRight: '150px'
    },
    link: {
        marginLeft: "30px"
    },
    barWhite: {
        marginLeft: "30px",
        borderLeft: "2px solid #fff !important"
    },
    itenPaginationActive: {
        color: "white",
        backgroundColor: "#3E6BFC",
        padding: '0px',
        height: '28px',
        width: '28px',
        borderRadius: "14px",
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: '14px',
        marginLeft: "5px",
        marginRight: "5px",
        cursor: "pointer"
    },
    itenPagination: {
        backgroundColor: "rgba(255,255,255,.6)",
        padding: '0px',
        height: '28px',
        width: '25px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: '14px',
        marginLeft: "5px",
        marginRight: "5px",
        cursor: "pointer",
        color: "#6F6F6F"
    },
    arrow: {
        marginRight: "10px",
        cursor: "pointer",
    },
    paginationSelect: {
        backgroundColor: "#54565B",
        border: "0px",
        outline: "none",
        minWidth: "60px",
        height: "24px",
        color: "#fff"
    },
    divSelectPagination: {
        display: "inline-block",
        border: "1px solid #fff",
        marginLeft: "10px",
        position: "relative"
    },
    divPaginationArrow: {
        position: "absolute",
        top: "0px",
        right: "0px",
        height: "100%",
        backgroundColor: "#fff",
        paddingLeft: "5px",
        paddingRight: "5px",
        pointerEvents: "none"
    }
});
