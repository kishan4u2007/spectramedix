import React from "react";
import "./style.scss";
import { faPlusSquare, faSortDown, faSortUp } from '@fortawesome/free-solid-svg-icons'
import IconProvider from "components/IconProvider";
import onClickOutside from "react-onclickoutside";
import CustomCheckBox from "../CustomCheckBox";
import Separator from "../Separator";
import arrowDropDown from "assets/images/arrow-drop-down.png"
import CustomRequiredLabel from "components/CustomRequiredLabel";

class CustomSelectCheckBox extends React.Component {

    state = {
        open: false
    }

    handleClickOutside = evt => {
        if (this.state.open) { this.setState({ open: false }) }
    };

    renderItemsSelecteds = () => {
        return (
            <div className="d-flex align-items-center">
                {this.props.selecteds.map((slc, key) => {
                    return (
                        <div>
                            {`${slc.value}${key + 1 == this.props.selecteds.length ? ", " : ""}`}
                        </div>
                    )
                })}
            </div>
        )
    }

    render() {
        return (
            <div className="custom-select-checkbox-container">
                <div className="selected d-flex align-items-center" onClick={() => this.setState({ open: !this.state.open })}>
                    <div className="opt flex-2">
                        {!this.props.selecteds || !this.props.selecteds.length ? "Select..."
                            :
                            this.renderItemsSelecteds()
                        }
                    </div>
                    <div className="flex-1 d-flex justify-content-end align-items-center">
                        <IconProvider
                            type="img"
                            icon={arrowDropDown}
                            className="arrow-dropdown"
                            onClick={() => this.setState({ open: !this.state.open })}
                        />
                    </div>
                </div>
                {this.state.open && !!this.props.options && !!this.props.options.length &&
                    <div className="opt-container">
                        {this.props.options.map((opt, k) => {
                            return (
                                <>
                                    <div className="opt">
                                        <CustomCheckBox checked={(() => {
                                            if (!this.props.selecteds) return false;
                                            const checked = !!this.props.selecteds.find((slc) => slc.value == opt.value);
                                            return checked;
                                        })()} onToggle={bool => this.props.onChange(bool, opt)} />
                                        <div className="opt-value">
                                            {opt.value}
                                        </div>
                                    </div>
                                    <div className={`separator-container ${k + 1 == this.props.options.length}`}>
                                        {k + 1 != this.props.options.length &&
                                            <Separator />
                                        }
                                    </div>
                                </>
                            )
                        })}
                    </div>
                }
                 <CustomRequiredLabel required={this.props.required} />
            </div>

        )
    }
}

CustomSelectCheckBox.defaultProps = {
    selecteds: [],
    options: []
}

export default onClickOutside(CustomSelectCheckBox);
