import React from "react";

export default ({ checked = false, onToggle = () => "" }) => {
    return (
        <div className="check-container">
            <input className="customcheck" type="checkbox" checked={checked} onChange={(e) => onToggle(!checked)} />
        </div>
    )
}