import React, { Component } from 'react';
import IconProvider from "components/IconProvider";
import { faEllipsisV } from '@fortawesome/free-solid-svg-icons'
import onClickOutside from "react-onclickoutside";

import './style.scss';

class PopUp extends Component {

    state = {
        open: false
    }

    handleClickOutside = evt => {
        if (this.state.open) { this.setState({ open: false }) }
    };

    render() {
        return (
            <div className="popup-container">
                <IconProvider
                    onClick={() => this.setState({ open: true })}
                    tool={true}
                    tool_id={"options"}
                    tool_text={"Options"}
                    type="fa"
                    icon={faEllipsisV}
                    style={{ color: "#929292" }}
                />
                {this.state.open && this.props.options.length > 0 &&
                    <div className="box-container">
                        {this.props.options.map((opt, key) => {
                            return (
                                <>
                                    <div className="pop-item" onClick={() => this.props.onClick(opt)}>
                                        {opt}
                                    </div>
                                    {key + 1 < this.props.options.length &&
                                        <div className="separator" />
                                    }
                                </>
                            )
                        })}
                    </div>
                }
            </div>
        );
    }
}

export default onClickOutside(PopUp);


PopUp.defaultProps = {
    options: []
}
