import React, { useState } from "react";
import { faEyeSlash, faEye, faExclamationCircle } from '@fortawesome/free-solid-svg-icons'
import IconProvider from "../../components/IconProvider";
import "./style.scss";

export default ({ placeHolder = "", name, ariaLabel, ariaDescribed, className, type = "text", leftImage, leftIcon, handleChange, required, error = false }) => {
    const [showPassword, setShowPassword] = useState(0);
    const realType = (type == 'password' ? showPassword == 0 ? type : 'text' : type);
    return (
        <div className="input-container">
            <div class="input-group">
                {!!leftImage &&
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <img src={leftImage} />
                        </span>
                    </div>
                }
                {!!leftIcon &&
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <IconProvider
                                tool={true}
                                tool_id={""}
                                tool_text={""}
                                type="fa"
                                style={{ color: '#678cfc' }}
                                icon={leftIcon}
                            />
                        </span>
                    </div>
                }
                <input name={name} type={realType} class="form-control custom-input" placeholder={placeHolder} aria-label="Username" aria-describedby="basic-addon1" onChange={(e) => handleChange(e.target)} required={required} />
                {type == 'password' &&
                    <div class="input-group-prepend" onClick={() => setShowPassword(!showPassword)}>
                        <span class="input-group-text">
                            {showPassword == 1 ?
                                <IconProvider
                                    tool={true}
                                    tool_id={"eye"}
                                    tool_text={"Eye"}
                                    type="fa"
                                    icon={faEye}
                                    style={{ color: '#ccc' }}
                                /> :
                                <IconProvider
                                    tool={true}
                                    tool_id={"eye_slash"}
                                    tool_text={"Eye Slash"}
                                    type="fa"
                                    icon={faEyeSlash}
                                    style={{ color: '#ccc' }}
                                />
                            }
                        </span>
                    </div>
                }
            </div>
            {!!error &&
                <span class="error_input">
                    <IconProvider icon={faExclamationCircle} style={{ fontSize: "13px", marginRight: "5px" }} />{error}
                </span>
            }
        </div>
    )
}