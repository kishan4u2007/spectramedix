import React from "react";
import "./style.scss";

export default ({ title, required }) => (
    <div className="d-flex customLabel">
        <div className="title"> {title}</div>
        {!!required &&
            <div className={`required ${required}`}>
                *
            </div>
        }
    </div>
)