// import axios from "config/axios";

export const add_new_contract_group = params => async () =>{
    // return await axios.post('/contract_group')
}