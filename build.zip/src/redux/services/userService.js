import axios from "config/axios";

export async function login(params) {
    if (params.email == "test@test.com" && params.password == "test") {
        return await axios.get("../../mocks/login.json", { ...params });
    }
    // return await axios.post('/login', {...params})
}

export async function logout() {
    return await axios.get("../../mocks/logout.json");
    // return await axios.post('/logout')
}
