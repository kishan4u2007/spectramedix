// import axios from "config/axios";
import faker from "faker";

function createFakeRow(index) {
    return {
        "Status": index % 2 == 0 ? "Active" : "Inactive",
        "Contract ID": index,
        "Contract Name": faker.company.companyName(),
        "Contract Group": faker.company.companyName(),
        "Client Type": faker.name.jobType(),
        "Contract Template": faker.name.jobArea(),
        "Contract Type": faker.name.jobArea(),
    };
}


export const list = async (count = 50) => {
    // return await axios.post('/login')
    return [...Array(count).keys()].map(i => createFakeRow(i));
}