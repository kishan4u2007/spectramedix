import { createStore, combineReducers, applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';
import reduxThunk from "redux-thunk";
import logger from 'redux-logger';
import userReducer from "redux/reducers/userReducer";
import homeReducer from "redux/reducers/homeReducer";
import contractReducer from "redux/reducers/contractReducer";

const persistConfig = {
  key: 'spectra_persist',
  storage,
  whitelist: ["userReducer"]
}

const combinedReducers = combineReducers({ userReducer, homeReducer, contractReducer });
const persistedReducer = persistReducer(persistConfig, combinedReducers)

export const store = createStore(persistedReducer, composeWithDevTools(applyMiddleware(reduxThunk, logger)));
window.store = store;
export const persistor = persistStore(store)

