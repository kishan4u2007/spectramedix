import { createSelector } from "reselect";
import _ from "lodash";
import * as contractService from "../services/contractService";

const initial = {
    contract: {
        lob: null,
        require:true,
        client_type: null,
        contract_group: null,
        contract_group_options: null,
        contract_name: null,
        contract_template: null,
        notes: null,
        group_type: null,
        funding_type: null,
        product_type: null,
        network: null,
        medical_stop: "Unlimited",
        drug_stop_loss: "Unlimited",
        geography_region: {
            all: false,
            checkeds: [],
            items: [{
                state: null,
                region: null,
                country: null,
                zip_code: null
            }]
        },
        fiscal_period_start: {value: "January"},
        length_of_period: { value: "12 Months" },
        runout_period:  {value: "3 months"},
        include_plurality_1: {
            bool: false,
            attributable_specialities: {
                options: [{ id: 0, name: "Carrier Wide", selected: false }, { id: 1, name: "Carrier Wide", selected: false }, { id: 2, name: "Carrier Wide", selected: false }, { id: 3, name: "Carrier Wide", selected: false }, { id: 4, name: "Carrier Wide", selected: false }, { id: 5, name: "Carrier Wide", selected: false }, { id: 5, name: "Carrier Wide" }],
                selecteds: []
            },
            attributable_services: {
                selecteds: [],
                options: [{ id: 0, name: "Carrier Wide" }, { id: 1, name: "Carrier Wide" }, { id: 2, name: "Carrier Wide" }, { id: 3, name: "Carrier Wide" }, { id: 4, name: "Carrier Wide" }, { id: 5, name: "Carrier Wide" }, { id: 5, name: "Carrier Wide" }]
            },
            attributable_places_of_service: [

            ],
            plurality_basis: null,
            lookback_period: {
                start_date: {
                    month: null,
                    year: null,
                },
                end_date: {
                    month: null,
                    year: null,
                }
            },
            attribution_tie_break: {
                1: null,
                2: null,
                3: null,
                4: null,
            }
        },
        include_plurality_2: {
            bool: false,
            attributable_specialities: [

            ],
            attributable_services: [

            ],
            attributable_places_of_service: [

            ],
            plurality_basis: null,
            lookback_period: {
                start_date: {
                    month: null,
                    year: null,
                },
                end_date: {
                    month: null,
                    year: null,
                }
            },
            attribution_tie_break: {
                1: null,
                2: null,
                3: null,
                4: null,
            }
        }
    },
    left_menu_new_contract: {
   
        1: {
            title: "Market Selection Steps",
            check: true,
            expanded: true,
            options: [
                { title: "Market Parameters", check: true, finished: false },
                { title: "Financial Benchmark", check: false, finished: false },
                { title: "Provider Network", check: false, finished: false }
            ],
            required_fields: [
                "lob", "group_type", "group_type", "product_type", "network",
            ],
            errors: []
        },
        2: {
            title: "Contract Parameters",
            check: true,
            expanded: false,
            options: [
                { title: "Attribution Methodology", check: false, finished: false },
                { title: "Attributed Population", check: false, finished: false },
                { title: "Select Quality Measures", check: false, finished: false },
                { title: "Define Measure Weights", check: false, finished: false },
            ]
        },
        3: {
            title: "Contract Parameter Selections",
            check: true,
            expanded: false,
            options: [
                { title: "Financial Benchmark", check: false, finished: false },
                { title: "Provider Network", check: false, finished: false },
            ]
        }
    },
    step: 0,
}

const types = {
    SET_INITIAL_CONTRACT: "SET_INITIAL_CONTRACT",
    EXPAND_SIDEBAR_FILTER: "EXPAND_SIDEBAR_FILTER",
    CREATE_NEW_CONTRACT_GROUP: "CREATE_NEW_CONTRACT_GROUP",
    CHANGE_CONTRACT_STEP: "CHANGE_CONTRACT_STEP",
    CHANGE_CONTRACT: "CHANGE_CONTRACT",
    SET_ERRORS: "SET_ERRORS"
}

const contractReducer = (state = initial, action) => {
    switch (action.type) {
        case types.SET_INITIAL_CONTRACT: {
            return initial;
        }
        case types.EXPAND_SIDEBAR_FILTER:
            return { ...state, left_menu_new_contract: action.payload }
        case types.CHANGE_CONTRACT_STEP:
            return {
                ...state,
                ...action.payload
            }
        case types.CHANGE_CONTRACT:
            return {
                ...state,
                contract: action.payload
            }

        case types.CREATE_NEW_CONTRACT_GROUP:
            return {
                ...state,
                contract: { ...state.contract, contract_group_options: action.payload }
            }

         case types.SET_ERRORS:
             return {
                 ...state,
                 left_menu_new_contract:{
                    ...state.left_menu_new_contract,
                    [state.step] : {
                        ...state.left_menu_new_contract[state.step],
                        errors: action.payload
                    }
                 }
             }   

    }
    return state;
};

export const toogle_expand_filter = payload => ({ type: types.EXPAND_SIDEBAR_FILTER, payload })

export const create_new_contract_group = payload => dispatch => {
    // await contractService.add_new_contract_group(payload);
    dispatch({ type: types.CREATE_NEW_CONTRACT_GROUP, payload });
}


export const setErrors = payload => ({ type: types.SET_ERRORS, payload })

export const changeStep = payload => ({ type: types.CHANGE_CONTRACT_STEP, payload })

export const left_menu_new_contract = state => state.contractReducer.left_menu_new_contract

export const step = state => state.contractReducer.step

export const changeContract = payload => ({ type: types.CHANGE_CONTRACT, payload })

export const getCurrentStep = createSelector(
    left_menu_new_contract, step, (currentMenu, menu) => {
        if (menu == 0) return {
            step: 0,
            nested_step: 0,
        }

        return Object.keys(currentMenu).reduce((initial, item, ) => {
            if (item == menu) {
                initial.step = item;
                const nested_step = _.findIndex((currentMenu[item].options), (opt) => !!opt.check)
                initial.nested_step = nested_step
            }

            return initial;
        }, { step: 0, nested_step: 0 });
    }
)

export const getContractTitle = createSelector(
    left_menu_new_contract, step,
    (currentMenu, menu) => {
        if (menu == 0) return "";

        const titles = {
            1: {
                title: "CREATE NEW CONTRACT / MARKET SELECTION STEPS / ",
                subtitle: {
                    ["0"]: "MARKET PARAMETERS",
                    ["1"]: "FINANCIAL BENCHMARK",
                    ["2"]: "PROVIDER NETWORK",
                }
            },
            2: {
                title: "CREATE NEW CONTRACT / CONTRACT PARAMETERS / ",
                subtitle: {
                    ["0"]: "ATTRIBUTION METHODOLOGY",
                    ["1"]: "FINANCIAL BENCHMARK",
                    ["2"]: "PROVIDER NETWORK",
                }
            }
        }

        const title = Object.keys(currentMenu).reduce((initial, item, ) => {
            if (item == menu) {
                const nested_step = _.findIndex((currentMenu[item].options), (opt) => !!opt.check)
                initial = titles[item].title + titles[item].subtitle[nested_step]
            }

            return initial;
        }, "");

        return title;
    }
)

export default contractReducer;
