import * as homeService from '../services/homeService';
import serializeRowHover from "helpers/serializeRowHover";
import { createSelector } from 'reselect'
import React, { Component } from 'react';


const initial = {
  contracts: [],
  search: "",
  qty_page: 20,
  currentPage: 0,
  canChangeQtyPage: false,
}

const types = {
  SET_HOME_INITIAL: "SET_HOME_INITIAL",
  SET_HOME_LIST: "SET_HOME_LIST",
  SORT_HOME_LIST: "SORT_HOME_LIST",
  SEARCH: "SEARCH",
  CHANGE_PAGE: "CHANGE_PAGE",
}

export const list = payload => async dispatch => {
  // dispatch({ type: types.SET_HOME_INITIAL });
  const list = await homeService.list();
  dispatch({ type: types.SET_HOME_LIST, payload: list });
}

export const sort = (sortColumn, sortDirection) => ({ type: types.SORT_HOME_LIST, sortColumn, sortDirection })

export const search = value => ({ type: types.SEARCH, value })

export const changePage = payload => ({ type: types.CHANGE_PAGE, payload })

const homeReducer = (state = initial, action) => {
  switch (action.type) {
    case types.SET_HOME_INITIAL: {
      return initial;
    }
    case types.SET_HOME_LIST: {
      return {
        ...state,
        contracts: action.payload
      }
    }
    case types.SORT_HOME_LIST: {
      return {
        ...state,
        contracts: action.sortDirection === "NONE" ? [...state.contracts] : [...state.contracts].sort((a, b) => comparer(a, b, action.sortColumn, action.sortDirection))
      }
    }
    case types.SEARCH: {
      return {
        ...state,
        search: action.value.toLowerCase()
      }
    }

    case types.CHANGE_PAGE: {
      return {
        ...state,
        currentPage: action.payload
      }
    }
  }
  return state;
};

const comparer = (a, b, sortColumn, sortDirection) => {
  if (sortDirection === "ASC") {
    return a[sortColumn] > b[sortColumn] ? 1 : -1;
  } else if (sortDirection === "DESC") {
    return a[sortColumn] < b[sortColumn] ? 1 : -1;
  }
};
const contracts_state = state => state.homeReducer.contracts;
const contracts_search = state => state.homeReducer.search;
const contracts_qty_page = state => state.homeReducer.qty_page;
const contracts_currentPage = state => state.homeReducer.currentPage;

export const contracts = createSelector(
  contracts_state, contracts_search, contracts_qty_page, contracts_currentPage,
  (ctrs, search, qty_page, page) => {
    if (!search.length) {
      ctrs = ctrs.map((i) => {
        return {
          ...i,
          ["Contract ID"]: [<div className={"ContractID"}>{i["Contract ID"]} </div>]
        }
      })
    } else {
      ctrs = ctrs.filter((contract) => contract["Contract Name"].toLowerCase().includes(search)).map((i) => {
        return {
          ...i,
          ["Contract ID"]: [<div className={"ContractID"}>{i["Contract ID"]} </div>]
        }
      })
    }

    const totalPages = (ctrs.length / qty_page) % 1 != 0 ? Math.ceil(ctrs.length / qty_page) : Math.ceil(ctrs.length / qty_page)

    const init = (page * qty_page) < 0 ? 0 : (page * qty_page);

    const end = totalPages == 0 ? ctrs : init + qty_page

    let contracts = (totalPages) == 1 ? ctrs : ctrs.slice(init, end);

    const { list } = serializeRowHover(contracts);

    return {
      contracts: list,
      totalPages
    };
  }
)

export default homeReducer;
