import { createSelector } from "reselect";
import _ from "lodash";
import * as userService from "../services/userService";

const initial = {
  user: null,
}

const types = {
  SET_USER_INITIAL: "SET_USER_INITIAL",
  SIGN_IN: "SIGN_IN",
  LOGOUT: "LOGOUT"
}

const userReducer = (state = initial, action) => {
  switch (action.type) {
    case types.SET_INITIAL_CONTRACT: {
      return initial;
    }
    case types.SIGN_IN: {
      return {
        ...state,
        user: action.payload
      }
    }
    case types.LOGOUT: {
      return initial;
    }

  }
  return state;
};

export default userReducer;

export const login = (params) => async dispatch => {
  try {
    const user = await userService.login(params)
    dispatch({ type: types.SIGN_IN, payload: user })
  }
  catch (e) {
    return await Promise.reject(e)
  }
}

export const logout = () => async dispatch => {
  try {
    const { success } = await userService.logout()
    if (!!success) {
      dispatch({ type: types.LOGOUT})
    }
  }
  catch (e) {
    return await Promise.reject(e)
  }
}
