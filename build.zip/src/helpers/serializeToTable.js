import React, { Component }  from 'react';

export default function serializeToTable (items) {

    let result = items.map((item) => {

        const keys = Object.keys(item);

        keys.map((itemKey) => {
            item[itemKey] = [<div className={itemKey} title={item[itemKey]} value={item[itemKey]}>{item[itemKey]}</div>]
        });

        return item;

    });
    return result;
}