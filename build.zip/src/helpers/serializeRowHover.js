import React, { Component } from 'react';

export default function serializeRowHover(list = []) {
    list = list.map((c, listKey) => {
        Object.keys(c).map((key) => {
            if (c[key] && c[key].length > 12) {
                const newValue = c[key].slice(0, 12).toString() + ".";
                c[key] = [
                    <div className={`${key} ${listKey} rowItem`} title={c[key]}>
                        {newValue}
                    </div>]
                return c;
            }
        });
        return c;
    })
    return {
        list,
    }
}