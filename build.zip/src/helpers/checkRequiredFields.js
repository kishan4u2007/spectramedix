export default (fields, requiredFields) => {
    
    let errors = [];

    requiredFields.forEach((field) => {
        if (!fields[field] || !fields[field].length) {
            errors.push(field);
        }
    });
    
    return errors;
}