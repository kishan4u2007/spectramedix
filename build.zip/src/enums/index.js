export const errorsEnum = {
    "required_field": "This field a required field",
    "invalid_format": "Check the format",
    "valid_email": "Please enter a valid e-mail address",
    "valid_password": "Please enter a valid password",
}